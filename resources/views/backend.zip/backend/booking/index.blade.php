@extends('backend.layouts.master')
@section('title','Bookings || Wishmytour Admin')
@section('main-content')
    <!-- Row -->
    <div class="row">
        <div class="col-sm-12">
            <div class="panel panel-default card-view">
                <div class="panel-heading">
                    <div class="pull-left">
                        <h6 class="panel-title txt-dark">All Booking</h6>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="panel-wrapper collapse in">
                    <div class="panel-body">
                        <div class="table-wrap">
                            <div class="table-responsive">
                                <table id="datable_1" class="table table-hover display  pb-30">
                               
          <thead>
            <tr>
              <th>Booking ID</th>
              <th>Package ID</th>
              <th>Package Name</th>
              <th>Vendor Name</th>
              <th>Customer Name</th>
              <th>Pax</th>
              <th>Booking On</th>
              <th>Tour Start Date</th>
              <th>Tour End Date</th>
             <th>Action</th>
            </tr>
          </thead>
          <tfoot>
            <tr>
              <th>Booking ID</th>
              <th>Package ID</th>
              <th>Package Name</th>
              <th>Vendor Name</th>
              <th>Customer Name</th>
              <th>Pax</th>
              <th>Booking On</th>
              <th>Tour Start Date</th>
              <th>Tour End Date</th>
             <th>Action</th>
              </tr>
          </tfoot>
          <tbody>
            @foreach($resultBookings as $booking)   
                <tr>
                   <td>#{{$booking->bookings_id}}</td>
                   <td>#{{$booking->package_id}}</td>
                   <td>{{$booking->name}}</td>
                   <td>{{$booking->vendor_fullname}}</td>
                   <td>{{$booking->customer_first_name}} {{$booking->customer_last_name}}</td>
                   <td>{{$booking->total_pax}}</td>
                   <td>{{$booking->created_at}}</td>
                   <td>{{$booking->first_booking_date}}</td>
                   <td>{{$booking->last_booking_date}}</td>
                   <td>
                      <a href="{{route('admin.booking.view',$booking->id)}}" class="pr-10" data-toggle="tooltip" data-original-title="Details">
                        <i class="fa fa-file-text-o" aria-hidden="true"></i></a>
                       <a href="javascript:void(0)" class="text-inverse" title=""data-toggle="tooltip" data-original-title="Delete">
                        <i class="zmdi zmdi-delete text-danger"></i></a>
                    </td>
                   
                    {{-- Delete Modal --}}
                    {{-- <div class="modal fade" id="delModal{{$user->id}}" tabindex="-1" role="dialog" aria-labelledby="#delModal{{$user->id}}Label" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="#delModal{{$user->id}}Label">Delete user</h5>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="modal-body">
                              <form method="post" action="{{ route('users.destroy',$user->id) }}">
                                @csrf 
                                @method('delete')
                                <button type="submit" class="btn btn-danger" style="margin:auto; text-align:center">Parmanent delete user</button>
                              </form>
                            </div>
                          </div>
                        </div>
                    </div> --}}
                </tr>  
            @endforeach
          </tbody>
        </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /Row -->
@endsection

@push('styles')

@endpush

@push('scripts')

<script type="text/javascript">
    $(document).ready(function() {
        // Initialize DataTable for datable_1
        $('#datable_1').DataTable();
    });
</script>

@endpush