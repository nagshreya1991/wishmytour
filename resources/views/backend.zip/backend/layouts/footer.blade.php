<!-- Footer -->
<footer class="footer container-fluid pl-30 pr-30">
    <div class="row">
        <div class="col-sm-12">
            <p>{{date('Y')}} &copy; Wishmytour. Pampered by ProperWebTechnologies</p>
        </div>
    </div>
</footer>
<!-- /Footer -->

</div>
<!-- /Main Content -->

</div>
<!-- /#wrapper -->

<!-- JavaScript -->

<!-- jQuery -->
<script src="{{asset('public/backend/vendors/bower_components/jquery/dist/jquery.min.js')}}"></script>

<!-- Bootstrap Core JavaScript -->
<script src="{{asset('public/backend/vendors/bower_components/bootstrap/dist/js/bootstrap.min.js')}}"></script>

<!-- Data table JavaScript -->
<script src="{{asset('public/backend/vendors/bower_components/datatables/media/js/jquery.dataTables.min.js')}}"></script>

<!-- Sweet-Alert  -->
<script src="{{asset('public/backend/vendors/bower_components/sweetalert/dist/sweetalert.min.js')}}"></script>

<!-- Init JavaScript -->
<script src="{{asset('public/backend/dist/js/init.js')}}"></script>


@stack('scripts')


