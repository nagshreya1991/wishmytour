<div class="fixed-sidebar-left">
    <ul class="nav navbar-nav side-nav nicescroll-bar">
        <li class="navigation-header">
            <span>Main</span>
            <i class="zmdi zmdi-more"></i>
        </li>
        <li>
            <a href="{{ route('admin.dashboard') }}" class="{{ request()->is('admin/dashboard') ? 'active' : '' }}">
                <div class="pull-left"><i class="zmdi zmdi-landscape mr-20"></i><span
                            class="right-nav-text">Dashboard</span></div>
                <div class="clearfix"></div>
            </a>
        </li>
        <li>
            <a href="javascript:void(0);" class="{{ request()->is(['admin/vendors','admin/customers']) ? 'active' : '' }}" data-toggle="collapse" data-target="#user_dr">
                <div class="pull-left"><i class="zmdi zmdi-accounts mr-20"></i><span class="right-nav-text">Users </span>
                </div>
                <div class="pull-right"><i class="zmdi zmdi-caret-down"></i></div>
                <div class="clearfix"></div>
            </a>
            <ul id="user_dr" class="collapse collapse-level-1 {{ request()->is(['admin/vendors','admin/customers']) ? 'in' : '' }}">
                <li>
                    <a href="{{route('admin.vendors')}}" class="{{ request()->is('admin/vendors') ? 'active-page' : '' }}">Vendors</a>
                </li>
                <li>
                    <a href="{{route('admin.customers')}}" class="{{ request()->is('admin/customers') ? 'active-page' : '' }}">Customers</a>
                </li>
            </ul>
        </li>
        <li>
            <a href="javascript:void(0);" class="{{ request()->is(['admin/packages','admin/inclusions','admin/exclusions','admin/locations']) ? 'active' : '' }}" data-toggle="collapse" data-target="#package_dr">
                <div class="pull-left"><i class="zmdi zmdi-collection-image mr-20"></i><span class="right-nav-text">Packages </span>
                </div>
                <div class="pull-right"><i class="zmdi zmdi-caret-down"></i></div>
                <div class="clearfix"></div>
            </a>
            <ul id="package_dr" class="collapse collapse-level-1 {{ request()->is(['admin/packages','admin/inclusions','admin/exclusions','admin/locations']) ? 'in' : '' }}">
                <li>
                    <a href="{{route('admin.packages')}}" class="{{ request()->is('admin/packages') ? 'active-page' : '' }}">Packages</a>
                </li>
                <li>
                    <a href="{{route('admin.inclusions.index')}}" class="{{ request()->is('admin/inclusions') ? 'active-page' : '' }}">Inclusions</a>
                </li>
                <li>
                    <a href="{{route('admin.exclusions.index')}}" class="{{ request()->is('admin/exclusions') ? 'active-page' : '' }}">Exclusions</a>
                </li>
                <li>
                    <a href="{{route('admin.locations.index')}}" class="{{ request()->is('admin/locations') ? 'active-page' : '' }}">Locations</a>
                </li>
            </ul>
        </li>
        <li>
            <a href="{{ route('admin.booking') }}" class="{{ request()->is('admin/booking') ? 'active' : '' }}">
                <div class="pull-left"><i class="zmdi zmdi-landscape mr-20"></i><span
                            class="right-nav-text">Bookings</span></div>
                <div class="clearfix"></div>
            </a>
        </li>   
    
    </ul>
</div>




