<?php namespace Modules\User\app\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Passport\HasApiTokens;

class User extends Authenticatable
{
    use HasFactory, Notifiable, HasApiTokens;

    const ROLE_ADMIN = 1;
    const ROLE_CUSTOMER = 2;
    const ROLE_VENDOR = 3;
    const ROLE_AGENT = 4;

    protected $fillable = [
        'name',
        'email',
        'mobile',
        //'password',
        'otp',
        'user_type',
        'verified'
    ];

    public function generateOtp(): string
    {
        $otp = strval(random_int(100000, 999999)); // Generate a random 6-digit OTP
        $this->update(['otp' => $otp]);

        return $otp;
    }

    public function verifyOtp($otp): bool
    {
        return $this->otp === $otp;
    }
    public function customerDetail()
    {
        return $this->hasOne(CustomerDetail::class);
    }
    public function vendorDetails()
    {
        return $this->hasOne(VendorDetails::class);
    }
}