<?php namespace Modules\User\app\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Passport\HasApiTokens;

class VendorDetails extends Authenticatable
{
    use HasFactory, Notifiable, HasApiTokens; 

    protected $table = 'vendor_details';

    protected $fillable = [
        'user_id',
        'fullname',
        'type_of_vendor',
        'address',
        'pancard',
        'pan_number',
        'have_gst',
        'gst_number',
        'organization_name',
        'organization_type',
        'proprietor_name',
        'proprietor_phone_number',
        'proprietor_pan',
        'proprietor_address',
        'no_of_partners',
        'no_of_directors',
        'status',
        'bank_person_name',
        'bank_acc_no',
        'ifsc_code',
        'bank_name',
        'branch_name',
        'cancelled_cheque',
        'authorization_letter',
        'pincode',
        'bank_verified'
    ];
    
    public function vendorPartners()
    {
        return $this->hasMany(VendorPartners::class, 'vendor_id', 'id');
    }
    public function vendorDirectors()
    {
        return $this->hasMany(VendorDirectors::class, 'vendor_id', 'id');
    }
    public function vendorBroadLocation()
    {
        return $this->hasMany(VendorBroadLocation::class, 'vendor_id', 'id');
    }
   
}