<?php

namespace Modules\User\App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Modules\User\app\Models\User;
use Modules\User\app\Models\CustomerDetail;
use Modules\User\app\Models\VendorDetails;
use Modules\User\app\Models\VendorPartners;
use Modules\User\app\Models\VendorDirectors;
use Modules\User\app\Models\VendorBroadLocation;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Modules\User\app\Http\Services\UserService;
use Illuminate\Http\JsonResponse;
use App\Rules\PANValidation;
use App\Rules\GSTValidation;
use Mail;
use App\Helpers\Helper;
use App\Models\Notification;

class UserController extends Controller
{

    private UserService $userService;

    public function __construct(UserService $userService)
    {
        $this->userService = $userService;
    }
    ///********************CUSTOMER SECTION*****************************/

    /**
     * Sign up/Sign in request by user
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function login(Request $request): JsonResponse
    { 
        $validator = Validator::make($request->all(), [
                'login' => 'required|string', // 'login' can be either email or mobile
            ]);
    
            if ($validator->fails()) {
                return response()->json(['res' => false, 'msg' => $validator->errors()->first(), 'data' => '']);
            }
    
            $login = $request->input('login');
    
            $existingCustomer = User::where('email', $login)->orWhere('mobile', $login)->first();
    
            if ($existingCustomer) {
                if ($existingCustomer->user_type == 2) {
                    $otp = $this->userService->generateOTP();
                    $existingCustomer->otp = $otp;
                    $existingCustomer->save();
    
                    $data = [
                        'customer' => $existingCustomer->id,
                        'action' => 'login',
                        'otp' => $otp,
                    ];
    
                    //$mailSent = Helper::sendMail($existingCustomer->email, $data);
                    $mailSent = Helper::sendMail($existingCustomer->email, $data, 'mail.otp', 'OTP sent successfully');

    
                    if ($mailSent) {
                        return response()->json(['res' => true, 'msg' => 'OTP sent successfully', 'data' => $data]);
                    } else {
                        return response()->json(['res' => false, 'msg' => 'Failed to send OTP', 'data' => '']);
                    }
                } else {
                    return response()->json(['res' => false, 'msg' => 'User not authenticated', 'data' => '']);
                }
            } else {
                // Generate and save OTP
                $otp = $this->userService->generateOTP();
                $result = $this->userService->saveOTP($login, $otp);
    
                if ($result) {
                    $lastInsertedId = \DB::getPdo()->lastInsertId();
                    $data = [
                        'customer' => $lastInsertedId,
                        'action' => 'register',
                        'otp' => $otp,
                    ];
    
                    if (filter_var($login, FILTER_VALIDATE_EMAIL)) {
                      //  $mailSent = Helper::sendMail($login, $data);
                        $mailSent = Helper::sendMail($login, $data, 'mail.otp', 'OTP sent successfully');

    
                        if ($mailSent) {
                            return response()->json(['res' => true, 'msg' => 'OTP sent successfully', 'data' => $data]);
                        } else {
                            return response()->json(['res' => false, 'msg' => 'Failed to send OTP', 'data' => '']);
                        }
                    } else {
                        return response()->json(['res' => false, 'msg' => 'Invalid email address provided', 'data' => '']);
                    }
                } else {
                    return response()->json(['res' => false, 'msg' => 'Failed to save OTP', 'data' => '']);
                }
            }
        }
    

    
    /**
     * Sign up/Sign in request by user
     *
     * @param Request $request
     *
     */

    public function verifyOTP(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'otp' => 'required|numeric',
            'customer' => 'required',
            'action' => 'required|in:login,register',
        ]);

        if ($validator->fails()) {
            return response()->json(['res' => false, 'msg' => 'Validation failed', 'errors' => $validator->errors()]);
        }

        $otp = $request->input('otp');
        $customer = $request->input('customer');
        $action = $request->input('action');

        $user = User::find($customer);

        if (!$user) {
            return response()->json(['res' => false, 'msg' => 'User not found', 'data' => '']);
        }

        $existingcustomerDetail = CustomerDetail::where('user_id', $user->id)->first();

        if ($existingcustomerDetail) {
            $customerDetail = "exist";
        } else {
            $customerDetail = "notexist";
        }

        if ($user->otp != '0' && $user->otp == $otp) {
            if ($action == 'login') {

                Auth::loginUsingId($user->id);

                $data = [
                    'customer_id' => $user->id,
                    'email' => !empty($user->email) ? $user->email : null,
                    'mobile' => !empty($user->mobile) ? $user->mobile : null,
                    'user_type' => 2,
                    'customerDetail' => $customerDetail,
                ];
                $token = $user->createToken('auth_token');

                return response()->json(['res' => true, 'msg' => 'Successfully logged in', 'data' => $data, 'token' => $token->accessToken]);
            } elseif ($action == 'register') {

                $userData = [
                    'email' => $user->email,
                    'mobile' => $user->mobile,

                ];

                //$newUser = User::create($userData);
                $otp2 = $this->userService->generateOTP();
                $user->update(['otp' => $otp2]); // Reset the OTP after successful registration
                $user->update(['user_type' => 2]);

                $data = [
                    'customer_id' => $user->id,
                    'email' => !empty($user->email) ? $user->email : null,
                    'mobile' => !empty($user->mobile) ? $user->mobile : null,
                    'user_type' => 2,
                    'customerDetail' => $customerDetail,

                ];


                $token = $user->createToken('auth_token');

               

                //Helper::sendNotification(34, "A new customer has been registered");
                return response()->json(['res' => true, 'msg' => 'Thank you for your patience', 'data' => $user, 'token' => $token->accessToken]);
            }


        } else {
            return response()->json(['res' => false, 'msg' => 'Provided confirmation code is not valid', 'data' => []]);
        }
    }

    /**
     * Register Details by user
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function addCustomer(Request $request): JsonResponse
    {

        $validator = Validator::make($request->all(), [
            'user_id' => 'required|exists:users,id',
            'first_name' => 'required|string|max:100',
            'last_name' => 'required|string|max:100',
            'state' => 'nullable|integer',
            'city' => 'nullable|integer',
            'zipcode' => 'nullable|string|max:100',
            'gender' => 'required|string|max:100',
        ]);

        if ($validator->fails()) {
            return response()->json(['res' => false, 'msg' => $validator->errors()->first(), 'data' => '']);
        }


        $userData = $request->only(['user_id', 'first_name', 'last_name', 'state', 'city', 'zipcode', 'gender']);


        $user = User::find($userData['user_id']);


        if (!$user || $user->user_type != 2) {
            return response()->json(['res' => false, 'msg' => 'Invalid user or user_type', 'data' => '']);
        }


        $existingCustomerDetail = CustomerDetail::where('user_id', $userData['user_id'])->first();

        if ($existingCustomerDetail) {
            return response()->json(['res' => false, 'msg' => 'CustomerDetail already exists for this user_id', 'data' => '']);
        }

        // $user->email =  $request->input('email');
        // $user->mobile =  $request->input('mobile');
        // $user->save();

        $user->update([
            'email' => $request->input('email', $user->email),
            'mobile' => $request->input('mobile', $user->mobile),
        ]);



        $customerDetails = CustomerDetail::create($userData);

        Helper::sendNotification(34, $customerDetails->first_name . " added details");

        return response()->json(['res' => true, 'msg' => 'Registration details saved successfully', 'data' => $customerDetails, 'user' => $user]);
    }

    /**
     * Register Details view by user
     *
     * @return mixed
     */
    public function registerDetailsView()
    {
        $user = Auth::user();

        if ($user) {

            $customerDetails = CustomerDetail::where('user_id', $user->id)->first();

            if ($customerDetails) {
                return response()->json(['res' => true, 'msg' => 'Customer details retrieved successfully', 'data' => $customerDetails, 'User' => $user]);
            } else {
                return response()->json(['res' => false, 'msg' => 'Customer details not found', 'data' => '']);
            }
        } else {
            return response()->json(['res' => false, 'msg' => 'User not authenticated', 'data' => '']);
        }
    }

    /**
     * Register Details Edit by user
     *
     * @param Request $request
     *
     */
    public function editCustomer(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'first_name' => 'required|string|max:100',
            'last_name' => 'required|string|max:100',
            'state' => 'nullable|integer',
            'city' => 'nullable|integer',
            'address' => 'nullable|string',
            'zipcode' => 'nullable|string|max:100',
            'gender' => 'required|string|max:100',
        ]);

        if ($validator->fails()) {
            return response()->json(['res' => false, 'msg' => $validator->errors()->first(), 'data' => '']);
        }

        $user = Auth::user();

        if ($user) {

            $customerDetails = CustomerDetail::where('user_id', $user->id)->first();

            if ($customerDetails) {

                $customerDetails->update($request->all());


                // $user->update([
                // 'email' => $request->input('email', $user->email),
                // 'mobile' => $request->input('mobile', $user->mobile),
                // ]);


                // $user->update(['email' => $request->input('email', $user->email)]);
                // $user->update(['mobile' => $request->input('mobile')]);
                $user->email = $request->input('email');
                $user->mobile = $request->input('mobile');
                $user->save();


                //  dd(  $user);
                return response()->json(['res' => true, 'msg' => 'Customer details updated successfully', 'data' => $customerDetails, 'user' => $user]);
            } else {
                return response()->json(['res' => false, 'msg' => 'Customer details not found', 'data' => '']);
            }
        } else {
            return response()->json(['res' => false, 'msg' => 'User not authenticated', 'data' => '']);
        }
    }

    /**
     * Add PhotoId by user
     *
     * @param Request $request
     *
     */
    public function addPhotoId(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'id_type' => 'required|string|in:pancard,aadharcard',
            'id_number' => 'required|string|max:50',
            //  'id_verified' => 'required|boolean',
        ]);

        if ($validator->fails()) {
            return response()->json(['res' => false, 'msg' => $validator->errors()->first(), 'data' => '']);
        }

        $user = Auth::user();

        if ($user) {

            $updatedCustomerDetails = $this->userService->addPhotoId(
                $user->id,
                $request->input('id_type'),
                $request->input('id_number'),
            // $request->input('id_verified')
            );

            if ($updatedCustomerDetails) {
                return response()->json(['res' => true, 'msg' => 'ID proof details added successfully', 'data' => $updatedCustomerDetails]);
            } else {
                return response()->json(['res' => false, 'msg' => 'Customer details not found', 'data' => '']);
            }
        } else {
            return response()->json(['res' => false, 'msg' => 'User not authenticated', 'data' => '']);
        }
    }

    /**
     * Change Phone Number by user
     *
     * @param Request $request
     *
     */
    public function changePhoneNumber(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'current_phone_number' => 'required|string',
            'new_phone_number' => 'required|string|different:current_phone_number',
            'confirm_new_phone_number' => 'required|string|same:new_phone_number',
        ]);

        if ($validator->fails()) {
            return response()->json(['res' => false, 'msg' => $validator->errors()->first(), 'data' => ''], 422);
        }

        $user = Auth::user();

        if (!$user) {
            return response()->json(['res' => false, 'msg' => 'User not authenticated', 'data' => '']);
        }


        if ($user->mobile !== $request->input('current_phone_number')) {
            return response()->json(['res' => false, 'msg' => 'Current phone number does not match', 'data' => '']);
        }


        $otp = $this->userService->generateOTP();


        $user->otp = $otp;
        //  $user->mobile = $request->new_phone_number; // Store temp phone number directly in user object
        $user->save();


        $data = [
            'user_id' => $user->id,
            'action' => 'change_phone_number',
            'otp' => $otp,
            'temp_phone_number' => $request->new_phone_number,
        ];

        return response()->json(['res' => true, 'msg' => 'OTP sent successfully', 'data' => $data]);
    }

    /**
     * Change Phone Number Verification by user
     *
     * @param Request $request
     *
     */
    public function verifyPhoneNumber(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'otp' => 'required|numeric',
            'temp_phone_number' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json(['res' => false, 'msg' => $validator->errors()->first(), 'data' => ''], 422);
        }

        $user = Auth::user();

        if (!$user) {
            return response()->json(['res' => false, 'msg' => 'User not authenticated', 'data' => '']);
        }


        if ($user->otp == $request->input('otp')) {

            $user->mobile = $request->temp_phone_number;
            $user->save();


            //  $user->temp_phone_number = null;
            // $user->save();

            return response()->json(['res' => true, 'msg' => 'Phone number changed successfully', 'data' => $user]);
        }

        return response()->json(['res' => false, 'msg' => 'Invalid OTP', 'data' => '']);
    }
    ///********************VENDOR SECTION*****************************/

    /**
     * Vendor Login
     *
     * @param Request $request
     * @return JsonResponse
     *
     */
    public function vendorLogin(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required_without:mobile|string',
            'mobile' => 'required_without:email|string',
        ]);
    
        if ($validator->fails()) {
            return response()->json(['res' => false, 'msg' => $validator->errors()->first(), 'data' => '']);
        }
    
        $email = $request->input('email');
        $mobile = $request->input('mobile');
    
        $existingCustomer = null;
        if (!empty($email)) {
            $existingCustomer = User::where('email', $email)->first();
        } elseif (!empty($mobile)) {
            $existingCustomer = User::where('mobile', $mobile)->first();
        }
    
        if ($existingCustomer) {
            if ($existingCustomer->user_type == 3) {
                if (!empty($email) && $existingCustomer->email !== $email) {
                    $existingCustomer->email = $email;
                }
                if (!empty($mobile) && $existingCustomer->mobile !== $mobile) {
                    $existingCustomer->mobile = $mobile;
                }
    
                $otp = $this->userService->generateOTP();
                $existingCustomer->otp = $otp;
                $existingCustomer->save();
    
                $data = [
                    'reg_type' => ($existingCustomer->email) ? 'email' : 'mobile',
                    'customer' => $existingCustomer->id,
                    'action' => 'login',
                    'user_type' => 3,
                    'otp' => $otp,
                ];
    
                $mailSent = Helper::sendMail($existingCustomer->email, $data, 'mail.otp', 'OTP sent successfully');
    
                return response()->json(['res' => true, 'msg' => 'OTP sent successfully', 'data' => $data]);
            } else {
                return response()->json(['res' => false, 'msg' => 'User not authenticated as a vendor', 'data' => '']);
            }
        } else {
            $otp = $this->userService->generateOTP();
            $result = $this->userService->vendorsaveOTP($email, $mobile, $otp);
    
            if ($result) {
                $lastInsertedId = \DB::getPdo()->lastInsertId();
    
                $data = [
                    'reg_type' => ($email) ? 'email' : 'mobile',
                    'customer' => $lastInsertedId,
                    'action' => 'register',
                    'user_type' => 3,
                    'otp' => $otp,
                ];
    
                $mailSent = Helper::sendMail($email, $data, 'mail.otp', 'OTP sent successfully');
    
                return response()->json(['res' => true, 'msg' => 'OTP sent successfully', 'data' => $data]);
            } else {
                return response()->json(['res' => false, 'msg' => 'Failed to send OTP', 'data' => '']);
            }
        }
    }
    

    /**
     * Vendor Login Verification
     *
     * @param Request $request
     *
     */
    public function vendorVerifyOTP(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'otp' => 'required|numeric',
            'customer' => 'required',
            'action' => 'required|in:login,register',
        ]);

        if ($validator->fails()) {
            return response()->json(['res' => false, 'msg' => 'Validation failed', 'errors' => $validator->errors()]);
        }

        $otp = $request->input('otp');
        $customer = $request->input('customer');
        $action = $request->input('action');

        $user = User::find($customer);

        if (!$user) {
            return response()->json(['res' => false, 'msg' => 'User not found', 'data' => '']);
        }

        $existingVendorDetail = VendorDetails::where('user_id', $user->id)->first();

        if ($existingVendorDetail) {
            $vendordetails = "exist";
        } else {
            $vendordetails = "notexist";
        }


        if ($user->otp != '0' && $user->otp == $otp) {
            //  $user->update(['verified' => 1]);
            if ($action == 'login') {


                Auth::loginUsingId($user->id);
                $bankAccNoExists = 0;
                if ($existingVendorDetail) {
                    $bankAccNoExists = VendorDetails::where('bank_acc_no', $existingVendorDetail->bank_acc_no)
                                                    ->whereNotNull('bank_acc_no') 
                                                    ->exists() ? 1 : 0;
                }
                $data = [
                    'customer_id' => $user->id,
                    'email' => !empty($user->email) ? $user->email : null,
                    'mobile' => !empty($user->mobile) ? $user->mobile : null,
                    'user_type' => 3,
                    'vendordetails' => $vendordetails,
                    'bankAccNoExists' => $bankAccNoExists,
                ];

                $token = $user->createToken('auth_token');

                return response()->json(['res' => true, 'msg' => 'Successfully logged in', 'data' => $data, 'token' => $token->accessToken]);


            } elseif ($action == 'register') {

                $userData = [
                    'email' => $user->email,
                    'mobile' => $user->mobile,

                ];

                //$newUser = User::create($userData);
                $otp2 = $this->userService->generateOTP();
                //$user->update(['verified' => 1]);
                $user->update(['otp' => $otp2]);
                $user->update(['user_type' => 3]);

                $data = [
                    'customer_id' => $user->id,
                    'email' => !empty($user->email) ? $user->email : null,
                    'mobile' => !empty($user->mobile) ? $user->mobile : null,
                    'user_type' => 3,
                    'vendordetails' => $vendordetails

                ];
                $token = $user->createToken('auth_token');
                Helper::sendNotification(34, "A new Vendor has been registered");
                /// dd($token);
                return response()->json(['res' => true, 'msg' => 'Thank you for your patience', 'data' => $data, 'token' => $token->accessToken]);
            }
        } else {
            return response()->json(['res' => false, 'msg' => 'Provided confirmation code is not valid', 'data' => []]);
        }
    }

    public function addVendorInformation(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'fullname' => 'required|string',
            'type_of_vendor' => 'required|string',
            'address' => 'required|string',
            'pincode' => 'required|string|max:100', 
            'pancard' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
            'pan_number' => ['required', 'string', new PANValidation, 'unique:vendor_details,pan_number'],
            'have_gst' => 'required|boolean',
           // 'gst_number' => $request->input('have_gst') ? 'required|string' : 'nullable|string', // Required if have_gst is true
            'gst_number' => $request->input('have_gst')
                ? ['required', 'string', new GSTValidation, 'unique:vendor_details,gst_number']
                : 'nullable|string',

            'organization_name' => $request->input('have_gst') ? 'nullable|string' : 'required|string', // Required if have_gst is false
            //  'organization_type' => 'required|integer|in:1,2,3',
            'proprietor_name' => 'nullable|string',
            'proprietor_phone_number' => 'nullable|string',
            'proprietor_pan' => 'nullable|string',
            'proprietor_address' => 'nullable|string',
            'no_of_partners' => 'nullable|integer',
            'no_of_directors' => 'nullable|integer',
            'status' => 'nullable|integer',
        ]);
        if ($validator->fails()) {
            return response()->json(['res' => false, 'msg' => $validator->errors()->first(), 'data' => ''], 200);
        }


        $user = Auth::user();


        if ($user && $user->user_type == 3) {

            $result = $this->userService->createVendorInformation($user, $request);

            if ($result['success']) {
                return response()->json(['res' => true, 'msg' => 'Vendor information added successfully', 'data' => $result]);
            } else {
                return response()->json(['res' => false, 'msg' => $result['msg'], 'data' => '']);
            }
        } else {
            return response()->json(['res' => false, 'msg' => 'User not authenticated as a vendor', 'data' => '']);
        }
    }


    public function editVendorInformation(Request $request)
    {
        $validator = Validator::make($request->all(), [
            // 'fullname' => 'required|string',
            'type_of_vendor' => 'required|string',
            // 'address' => 'required|string',
            // 'pancard' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
            //  'pan_number' => 'required|string',
            //  'have_gst' => 'required|boolean',
            //  'gst_number' => $request->input('have_gst') ? 'required|string' : 'nullable|string', // Required if have_gst is true
            // 'organization_name' => 'nullable|string', // Required if have_gst is false
            //  'organization_type' => 'required|integer|in:1,2,3',
            'proprietor_name' => 'nullable|string',
            'proprietor_phone_number' => 'nullable|string',
            'proprietor_pan' => 'nullable|string',
            'proprietor_address' => 'nullable|string',
            'no_of_partners' => 'nullable|integer',
            'no_of_directors' => 'nullable|integer',
            'status' => 'nullable|integer',
        ]);

        if ($validator->fails()) {
            return response()->json(['res' => false, 'msg' => $validator->errors()->first(), 'data' => null], 200);
        }

        $user = Auth::user();

        if ($user && $user->user_type == 3) {
            $result = $this->userService->editVendorInformation($user, $request);

            if ($result['success']) {
                return response()->json(['res' => true, 'msg' => 'Vendor information updated successfully', 'data' => $result]);
            } else {
                return response()->json(['res' => false, 'msg' => $result['msg'], 'data' => null], 500);
            }
        } else {
            return response()->json(['res' => false, 'msg' => 'User not authenticated as a vendor', 'data' => null], 403);
        }
    }


    public function vendorUserProfileView()
    {
        try {
            $user = Auth::user();
            if ($user && $user->user_type == 3) {
                $vendorDetails = VendorDetails::with('vendorPartners', 'vendorDirectors')
                    ->where('user_id', $user->id)
                    ->first();
                if ($vendorDetails) {
                    $organization_type = "";
                    switch ($vendorDetails->organization_type) {
                        case 1:
                            $organization_type = "Proprietor";
                            break;
                        case 2:
                            $organization_type = "Partnership";
                            break;
                        case 3:
                            $organization_type = "Private Limited";
                            break;
                        default:
                            $organization_type = "Unknown";
                            break;
                    }


                    $states = [];
                    $cities = [];

                    $vendorBroadLocations = DB::table('vendor_broad_location')
                        ->join('states', 'vendor_broad_location.state', '=', 'states.id')
                        ->join('cities', 'vendor_broad_location.city', '=', 'cities.id')
                        ->where('vendor_broad_location.vendor_id', $vendorDetails->id)
                        ->select(
                            'vendor_broad_location.*',
                            'states.name as state_name',
                            'cities.city as city_name'
                        )
                        ->get();

                    return response()->json([
                        'res' => true,
                        'msg' => 'Vendor information retrieved successfully',
                        'user' => $user,
                        'data' => $vendorDetails,
                        'organization_type' => $organization_type,
                        'vendorBroadLocations' => $vendorBroadLocations->toArray(),
                        //'cities' => $cities,
                    ]);
                } else {
                    return response()->json([
                        'res' => true,
                        'msg' => 'Vendor details not found',
                        'data' => null
                    ], 200);
                }
            } else {
                return response()->json([
                    'res' => false,
                    'msg' => 'User not authenticated as a vendor',
                    'data' => null
                ], 403);
            }
        } catch (\Exception $e) {
            return response()->json([
                'res' => false,
                'msg' => $e->getMessage(),
                'data' => null
            ], 500);
        }
    }


    public function editVendorUserProfile(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'fullname' => 'required|string',
            'email' => 'required|email',
            'mobile' => 'required|string',
            'address' => 'required|string',
            'pincode' => 'required|string|max:100', 
            //  'pancard' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
            'pan_number' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json(['res' => false, 'msg' => $validator->errors()->first(), 'data' => null], 200);
        }


        $user = $request->user();

        if ($user && $user->user_type == 3) {

            $result = $this->userService->editVendorUser($user, $request);

            $result = ['success' => true, 'msg' => 'Vendor information updated successfully'];

            if ($result['success']) {
                return response()->json(['res' => true, 'msg' => $result['msg'], 'data' => $result], 200);
            } else {
                return response()->json(['res' => false, 'msg' => $result['msg'], 'data' => null], 500);
            }
        } else {
            return response()->json(['res' => false, 'msg' => 'User not authenticated as a vendor', 'data' => null], 403);
        }
    }

    public function addBankingAccountVendor(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'bank_person_name' => 'nullable|string',
            'bank_acc_no' => 'nullable|string',
            'ifsc_code' => 'nullable|string',
            'bank_name' => 'nullable|string',
            'branch_name' => 'nullable|string',
            'cancelled_cheque' => 'nullable|file|mimes:jpeg,png,jpg,pdf|max:2048',
            'authorization_letter' => 'nullable|file|mimes:jpeg,png,jpg,pdf|max:2048',
        ]);

        if ($validator->fails()) {
            return response()->json(['res' => false, 'msg' => $validator->errors()->first(), 'data' => ''], 200);
        }

        $user = Auth::user();

        if ($user && $user->user_type == 3) {
            $result = $this->userService->addBankingAccountDetails($user, $request);

            if ($result['success']) {
                return response()->json(['res' => true, 'msg' => 'Banking account information added successfully', 'data' => $result['vendorDetails']]);
            } else {
                return response()->json(['res' => false, 'msg' => $result['msg'], 'data' => '']);
            }
        } else {
            return response()->json(['res' => false, 'msg' => 'User not authenticated as a vendor', 'data' => '']);
        }
    }


    public function logout(Request $request)
    {
        auth()->logout();

        $request->session()->flush();

        return response()->json(['msg' => 'Successfully logged out']);
    }

     //Admin Login
    public function adminLogin(Request $request)
    {
       
        $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

       
        $user = User::where('email', $request->email)->first();

        if (!$user || !Hash::check($request->password, $user->password)) {
           
            return response()->json(['error' => 'Invalid credentials'], 401);
        }

       
        if ($user->user_type !== 1) {
           
            return response()->json(['error' => 'Unauthorized'], 401);
        }

       
        $token = $user->createToken('auth_token');
        return response()->json(['res' => true, 'msg' => 'Successfully logged in', 'data' => $user, 'token' => $token->accessToken], 200);
    }


    //Notification

    public function notificationlist(Request $request)
    {
        $user = Auth::user();
        $receiverId = $user->id;
        $notifications = Notification::getByReceiverId($receiverId);
        $unreadCount = Notification::unreadNotificationsCount($receiverId);
        
        return response()->json([
            'notifications' => $notifications,
            'unread_count' => $unreadCount
        ]);
    }
    public function markAsRead(Notification $notification)
    {
        $notification->markAsRead();
        
        return response()->json(['message' => 'Notification marked as read']);
    }

    public function markAllAsRead()
    {
        $user = Auth::user();
        $receiverId = $user->id;
        
        Notification::markAllAsRead($receiverId);

        return response()->json(['message' => 'All notifications marked as read']);
    }

    public function markAsUnread(Notification $notification)
    {
        $notification->markAsUnread();
        
        return response()->json(['message' => 'Notification marked as unread']);
    }

    public function removeAllNotifications()
   {
    try {
        $userId = auth()->id();
        // Delete all notifications for the logged-in user
        Notification::where('receiver_id', $userId)->delete();
       // return response()->json(['success' => true]);
        return response()->json(['msg' => 'All Notifications removed Successfully']);
    } catch (\Exception $e) {
        return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
    }
    }
    
}