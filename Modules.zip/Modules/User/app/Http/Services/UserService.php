<?php

namespace Modules\User\App\Http\Services;

use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\DB;
use Modules\User\app\Models\User;
use Illuminate\Support\Facades\Validator;
use Modules\User\app\Models\CustomerDetail;
use Modules\User\app\Models\VendorDetails;
use Modules\User\app\Models\VendorPartners;
use Modules\User\app\Models\VendorDirectors;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use Modules\User\app\Models\VendorBroadLocation;
use Carbon\Carbon;
use App\Helpers\Helper;


class UserService
{
    protected User $user;
    public function generateOTP()
    {
        $otp = rand(1000, 9999);
        return strval($otp);
    }

    public function saveOTP($login, $otp)
    {
        $userData = [
        'otp' => $otp,
        'user_type' => 2,
        ];

        // Determine if $login is an email or mobile
        if (filter_var($login, FILTER_VALIDATE_EMAIL)) {
        // If $login is a valid email address
        $userData['email'] = $login;
        } else {
        // If $login is not a valid email, assume it's a mobile number
        $userData['mobile'] = $login;
        }

        $result = User::create($userData);

        return $result;
    }

        
    public function addPhotoId($userId, $idType, $idNumber)
    {
    // Fetch and update customer details with ID proof information
    $customerDetails = CustomerDetail::where('user_id', $userId)->first();

    if ($customerDetails) {
    $customerDetails->update([
    'id_type' => $idType,
    'id_number' => $idNumber,
    //  'id_verified' => $idVerified,
    ]);

    return $customerDetails;
    }

    return null;
    }

    public function verifyPhoneOTP(User $user, $otp)
    {
        // Implement OTP verification logic here
        return $user->otp === $otp;
    }

    //******VENDOR SECTION*************/

        public function vendorsaveOTP($email= null, $mobile= null, $otp)
        {
        
        $email = $email ?? null; 

        $mobile = $mobile ?? null; 

        $result = User::create([
            'email' => $email,
            'mobile' => $mobile,
            'otp' => $otp,
            'user_type' => 3,
        ]);

        return $result;
        }

        /**
     * Create vendor information for the authenticated user.
     *
     * @param Modules\User\app\Models\User $user
     * @param array $vendorDetailsData
     * @return array
     */
    public function createVendorInformation($user, $request): array
   {
    $existingVendorDetail = VendorDetails::where('user_id', $user->id)->first();

    if ($existingVendorDetail) {
        return ['success' => false, 'msg' => 'Vendor details already exist for this user'];
    }

    // Create a new instance of VendorDetails
    $vendorDetails = new VendorDetails();

    $vendorDetails->user_id = $user->id;
    $vendorDetails->fullname = $request->fullname;
    $vendorDetails->type_of_vendor = $request->type_of_vendor;
    $vendorDetails->address = $request->address;
    $vendorDetails->pincode = $request->pincode;
    $vendorDetails->pan_number = $request->pan_number;
    $vendorDetails->have_gst = $request->have_gst;
    $vendorDetails->gst_number = $request->gst_number;
    $vendorDetails->organization_name = $request->organization_name;
    $vendorDetails->organization_type = $request->organization_type;
    $vendorDetails->proprietor_name = $request->proprietor_name;
    $vendorDetails->proprietor_phone_number = $request->proprietor_phone_number;
    $vendorDetails->proprietor_pan = $request->proprietor_pan;
    $vendorDetails->proprietor_address = $request->proprietor_address;
    $vendorDetails->no_of_partners = $request->no_of_partners;
    $vendorDetails->no_of_directors = $request->no_of_directors;
    $vendorDetails->status = $request->status;

    // Handle the pancard image upload
    if ($request->hasFile('pancard')) {
        $pancardImage = $request->file('pancard');

        if ($pancardImage->isValid()) {
            $filename = time() . '_' . $pancardImage->getClientOriginalName();
            $pancardImage->storeAs('public/vendor_files', $filename);
            $vendorDetails->pancard = 'vendor_files/' . $filename;
        } else {
            return ['success' => false, 'msg' => 'Invalid pancard image file'];
        }
    }

    // Save the vendor details
    if (!$vendorDetails->save()) {
        return ['success' => false, 'msg' => 'Failed to save vendor details'];
    }

    // Add entries to VendorPartners table
    $vendorPartners = $request->vendor_partners;//dd($vendorPartners );
    if ($vendorPartners && is_array($vendorPartners)) {
        foreach ($vendorPartners as $partner) {
            VendorPartners::create([
                'vendor_id' => $vendorDetails->id,
                'partner_name' => $partner['partner_name'],
                'phone_number' => $partner['phone_number'],
                'pan_number' => $partner['pan_number'],
                'address' => $partner['address'],
            ]);
        }
    }

     // Add entries to VendorDirectors table
     $vendorDirectors = $request->vendor_directors;//dd($vendorPartners );
     if ($vendorDirectors && is_array($vendorDirectors)) {
         foreach ($vendorDirectors as $director) {
            VendorDirectors::create([
                 'vendor_id' => $vendorDetails->id,
                 'director_name' => $director['director_name'],
                 'phone_number' => $director['phone_number'],
                 'pan_number' => $director['pan_number'],
                 'address' => $director['address'],
             ]);
         }
     }

       // Add entries to VendorDirectors table
       $vendorBroadLocation = $request->vendor_broad_location;//dd($vendorPartners );
       if ($vendorBroadLocation && is_array($vendorBroadLocation)) {
           foreach ($vendorBroadLocation as $broadLocation) {
            VendorBroadLocation::create([
                   'vendor_id' => $vendorDetails->id,
                   'state' => $broadLocation['state'],
                   'city' => $broadLocation['city'],
                   
               ]);
           }
       }
       Helper::sendNotification($user->id, "You added your details");
       Helper::sendNotification(34, $vendorDetails->fullname . "a new vendor added details");

    return ['success' => true, 'vendorDetails' => $vendorDetails, 'vendorPartners' => $vendorPartners, 'vendorDirectors' => $vendorDirectors, 'vendorBroadLocation' => $vendorBroadLocation];

}

public function editVendorInformation($user, $request): array
{
    $vendorDetails = VendorDetails::where('user_id', $user->id)->first();

    if (!$vendorDetails) {
        return ['success' => false, 'msg' => 'Vendor details not found for this user'];
    }

    // Update vendor details
   
  //  $vendorDetails->fullname = $request->fullname;
    $vendorDetails->type_of_vendor = $request->type_of_vendor;
  //  $vendorDetails->address = $request->address;
  //  $vendorDetails->pan_number = $request->pan_number;
  //  $vendorDetails->have_gst = $request->have_gst;
  //  $vendorDetails->gst_number = $request->gst_number;
    $vendorDetails->organization_name = $request->organization_name;
    $vendorDetails->organization_type = $request->organization_type;
    $vendorDetails->proprietor_name = $request->proprietor_name;
    $vendorDetails->proprietor_phone_number = $request->proprietor_phone_number;
    $vendorDetails->proprietor_pan = $request->proprietor_pan;
    $vendorDetails->proprietor_address = $request->proprietor_address;
    $vendorDetails->no_of_partners = $request->no_of_partners;
    $vendorDetails->no_of_directors = $request->no_of_directors;
    $vendorDetails->status = $request->status;

    // Handle pancard image upload if provided
    if ($request->hasFile('pancard')) {
        $pancardImage = $request->file('pancard');

        if ($pancardImage->isValid()) {
            $filename = time() . '_' . $pancardImage->getClientOriginalName();
            $pancardImage->storeAs('public/vendor_files', $filename);
            $vendorDetails->pancard = 'vendor_files/' . $filename;
        } else {
            return ['success' => false, 'msg' => 'Invalid pancard image file'];
        }
    }

    // Save the updated vendor details
    if (!$vendorDetails->save()) {
        return ['success' => false, 'msg' => 'Failed to update vendor details'];
    }

     // Add entries to VendorPartners table
     $vendorPartners = $request->vendor_partners;//dd($vendorPartners );
     if ($vendorPartners && is_array($vendorPartners)) {
        VendorPartners::where('vendor_id', $vendorDetails->id)->delete();
         foreach ($vendorPartners as $partner) {
             VendorPartners::create([
                 'vendor_id' => $vendorDetails->id,
                 'partner_name' => $partner['partner_name'],
                 'phone_number' => $partner['phone_number'],
                 'pan_number' => $partner['pan_number'],
                 'address' => $partner['address'],
             ]);
         }
     }
 
      // Add entries to VendorDirectors table
      $vendorDirectors = $request->vendor_directors;//dd($vendorPartners );
      if ($vendorDirectors && is_array($vendorDirectors)) {
        VendorDirectors::where('vendor_id', $vendorDetails->id)->delete();
          foreach ($vendorDirectors as $director) {
             VendorDirectors::create([
                  'vendor_id' => $vendorDetails->id,
                  'director_name' => $director['director_name'],
                  'phone_number' => $director['phone_number'],
                  'pan_number' => $director['pan_number'],
                  'address' => $director['address'],
              ]);
          }
      }
 
        // Add entries to VendorDirectors table
        $vendorBroadLocation = $request->vendor_broad_location;//dd($vendorPartners );
        if ($vendorBroadLocation && is_array($vendorBroadLocation)) {
            VendorBroadLocation::where('vendor_id', $vendorDetails->id)->delete();
            foreach ($vendorBroadLocation as $broadLocation) {
             VendorBroadLocation::create([
                    'vendor_id' => $vendorDetails->id,
                    'state' => $broadLocation['state'],
                    'city' => $broadLocation['city'],
                    
                ]);
            }
        }

    
    return ['success' => true,'msg' => 'Vendor information updated successfully',  'vendorDetails' => $vendorDetails, 'vendorPartners' => $vendorPartners, 'vendorDirectors' => $vendorDirectors, 'vendorBroadLocation' => $vendorBroadLocation];
}

public function editVendorUser($user, Request $request)
{
    try {
        $vendorDetails = VendorDetails::where('user_id', $user->id)->first();
        if (!$vendorDetails) {
            return ['success' => false, 'msg' => 'Vendor details not found'];
        }

        // Update user details
        $user->email = $request->input('email');
        $user->mobile = $request->input('mobile');
        $user->save();
      //  $vendorDetails = new VendorDetails();
        // Update vendor details
        $vendorDetails->fullname = $request->input('fullname');
        $vendorDetails->address = $request->input('address');
        $vendorDetails->pincode = $request->input('pincode');
        $vendorDetails->pan_number = $request->input('pan_number');
//dd($request->input('fullname'));
        // Handle the pancard image upload
        if ($request->hasFile('pancard')) {
            $pancardImage = $request->file('pancard');

            if ($pancardImage->isValid()) {
                $filename = time() . '_' . $pancardImage->getClientOriginalName();
                $pancardImage->storeAs('public/vendor_files', $filename);
                $vendorDetails->pancard = 'vendor_files/' . $filename;
            } else {
                return ['success' => false, 'msg' => 'Invalid pancard image file'];
            }
        }
        $vendorDetails->save();
        return ['success' => true, 'msg' => 'Vendor information updated successfully']; // Ensure 'message' key is defined
    } catch (\Exception $e) {
       return ['success' => false, 'msg' => $e->getMessage()];
    }
}
   public function addBankingAccountDetails($user, $request)
    {
        $vendorDetails = VendorDetails::firstOrCreate(['user_id' => $user->id]);

     // Handle the cancelled_cheque file upload
     if ($request->hasFile('cancelled_cheque')) {
        // Clear previous file if it exists
        if ($vendorDetails->cancelled_cheque) {
            Storage::delete($vendorDetails->cancelled_cheque);
            $vendorDetails->cancelled_cheque = null; // Remove file path from the database
        }

        $cancelledChequeFile = $request->file('cancelled_cheque');

        if ($cancelledChequeFile->isValid()) {
            $filename = uniqid() . '_' .$vendorDetails->user_id. '_'.$cancelledChequeFile->getClientOriginalName();
            $cancelledChequeFile->storeAs('public/vendor_files/banking_details', $filename);
            $vendorDetails->cancelled_cheque = 'vendor_files/banking_details/' . $filename;
        } else {
            // If the file upload fails, return an error response
            return ['success' => false, 'msg' => 'Invalid cancelled_cheque image file'];
        }
    }

    // Handle the authorization_letter file upload
    if ($request->hasFile('authorization_letter')) {
        // Clear previous file if it exists
        if ($vendorDetails->authorization_letter) {
            Storage::delete($vendorDetails->authorization_letter);
            $vendorDetails->authorization_letter = null; // Remove file path from the database
        }

        $authorizationLetterFile = $request->file('authorization_letter');

        if ($authorizationLetterFile->isValid()) {
            $filename = uniqid() . '_' .$vendorDetails->user_id. '_' . $authorizationLetterFile->getClientOriginalName();
            $authorizationLetterFile->storeAs('public/vendor_files/banking_details', $filename);
            $vendorDetails->authorization_letter = 'vendor_files/banking_details/' . $filename;
        } else {
            // If the file upload fails, return an error response
            return ['success' => false, 'msg' => 'Invalid authorization_letter image file'];
        }
    }




        $vendorDetails->update([
            'bank_person_name' => $request->bank_person_name,
            'bank_acc_no' => $request->bank_acc_no,
            'ifsc_code' => $request->ifsc_code,
            'bank_name' => $request->bank_name,
            'branch_name' => $request->branch_name,
        ]);

        return ['success' => true, 'vendorDetails' => $vendorDetails];
    }
}
