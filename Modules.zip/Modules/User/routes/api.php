<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Modules\User\app\Http\Controllers\UserController;


//User login 'user_type' => 2
Route::post('/login', [UserController::class, 'login']);
Route::post('/verify-otp', [UserController::class, 'verifyOTP']);
Route::post('/add-customer', [UserController::class, 'addCustomer']);
Route::middleware('auth:api')->post('/customer-details-view', [UserController::class, 'registerDetailsView']);
Route::middleware('auth:api')->post('/edit-customer', [UserController::class, 'editCustomer']);
Route::middleware('auth:api')->post('/add_photo_id', [UserController::class, 'addPhotoId']);
Route::middleware('auth:api')->group(function () {
    Route::post('/change-phone-number', [UserController::class, 'changePhoneNumber']);
    Route::post('/verify-phone-number', [UserController::class, 'verifyPhoneNumber']);
    Route::post('/logout', [UserController::class, 'logout']);
});


//Vendor login 'user_type' => 3
Route::post('/vendor-login', [UserController::class, 'vendorLogin']);
Route::post('/vendor-verify-otp', [UserController::class, 'vendorVerifyOTP']);
Route::middleware('auth:api')->group(function () {
    Route::post('/add-vendor-information', [UserController::class, 'addVendorInformation']);
    Route::post('/edit-vendor-information', [UserController::class, 'editVendorInformation']);
    Route::post('/vendor-user-profile-view', [UserController::class, 'vendorUserProfileView']);
    Route::post('/edit-vendor-user-profile', [UserController::class, 'editVendorUserProfile']);
    Route::post('/add-banking-account-vendor', [UserController::class, 'addBankingAccountVendor']);

    // Route to fetch notifications
    Route::get('/notifications', [UserController::class, 'notificationlist']);
    
    // Route to mark a notification as read
    Route::put('/notifications/mark-as-read', [UserController::class, 'markAllAsRead']);
    
    // Route to mark a notification as unread
    Route::put('/notifications/{notification}/mark-as-unread', [UserController::class, 'markAsUnread']);
    Route::post('/notifications/remove-all', [UserController::class, 'removeAllNotifications']);
   
});

//Admin login 'user_type' => 1
Route::post('/admin-login', [UserController::class, 'adminLogin']);