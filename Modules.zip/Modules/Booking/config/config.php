<?php

return [
    'name' => 'Booking',
];
