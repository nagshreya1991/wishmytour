<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Modules\Booking\app\Http\Controllers\BookingController;
/*
    |--------------------------------------------------------------------------
    | API Routes
    |--------------------------------------------------------------------------
    |
    | Here is where you can register API routes for your application. These
    | routes are loaded by the RouteServiceProvider within a group which
    | is assigned the "api" middleware group. Enjoy building your API!
    |
*/

Route::middleware('auth:api')->group(function () {
Route::post('/add-booking', [BookingController::class, 'addBooking']);
Route::post('/upcoming-booking', [BookingController::class, 'upcomingBooking']);
Route::post('/completed-booking', [BookingController::class, 'completedBooking']);

  // Prefix vendor routes
  Route::prefix('vendor')->group(function () {
  Route::post('/booking-list', [BookingController::class, 'vendorBookingList']);
  });


});
Route::get('/taxes', [BookingController::class, 'fetchTaxes']);