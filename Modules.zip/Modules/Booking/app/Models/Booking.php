<?php

namespace Modules\Booking\app\Models;

use Illuminate\Database\Eloquent\Model;
use Modules\Booking\app\Models\BookingRoom;
use Modules\Booking\app\Models\BookingDate;
use Modules\Booking\app\Models\BookingCustomerDetails;

class Booking extends Model
{
    protected $fillable = [
        'package_id', 'customer_id', 'add_on_id', 'booking_status'
    ];

    public function rooms()
    {
        return $this->hasMany(BookingRoom::class);
    }

    public function dates()
    {
        return $this->hasMany(BookingDate::class);
    }

    public function customer()
    {
        return $this->hasOne(BookingCustomerDetails::class);
    }
}