<?php

namespace Modules\Booking\app\Http\Controllers;

use App\Helpers\Helper;
use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Modules\Booking\app\Http\Services\BookingService;
use Modules\Booking\app\Http\Requests\AddBookingRequest;
use Modules\User\app\Models\User;
use Modules\Package\app\Models\Package;


class BookingController extends Controller
{
    private $bookingService;

    public function __construct(BookingService $bookingService)
    {
        $this->bookingService = $bookingService;
    }

    public function addBooking(AddBookingRequest $request)
    {
        if (auth()->check()) {
            if (auth()->user()->user_type === User::ROLE_CUSTOMER) {

                $result = $this->bookingService->addBooking($request->validated());

                return response()->json($result);
            } else {
                return response()->json(['error' => 'User type not authorized to add bookings'], 403);
            }
        } else {
            return response()->json(['error' => 'Unauthorized'], 401);
        }
    }

    public function upcomingBooking()
    {
        try {
            $userId = auth()->id();
            if (!$userId) {
                return response()->json(['error' => 'Unauthorized'], 401);
            }

            $upcomingBookings = $this->bookingService->getUpcomingBookingsForUser($userId);

            $resultBookings = $upcomingBookings->map(function ($booking) {

                $package = Package::where('id', $booking->package_id)->first();
                $totalDays = $package->total_days;
                $totalNights = $package->fetchStayPlans()->sum('total_nights');
                $totalDaysAndNights = "$totalDays days and $totalNights night" . ($totalNights > 1 ? 's' : '');
                $booking->total_days = $totalDaysAndNights;
                return $booking;
            });

            return response()->json(['res' => true, 'msg' => 'Upcoming Bookings retrieved successfully', 'data' => $resultBookings], 200);

        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function completedBooking()
    {
        try {
            $userId = auth()->id();
            if (!$userId) {
                return response()->json(['error' => 'Unauthorized'], 401);
            }

            $completedBookings = $this->bookingService->getCompletedBookingsForUser($userId);

            $resultBookings = $completedBookings->map(function ($booking) {

                $package = Package::where('id', $booking->package_id)->first();
                $totalDays = $package->total_days;
                $totalNights = $package->fetchStayPlans()->sum('total_nights');
                $totalDaysAndNights = "$totalDays days and $totalNights night" . ($totalNights > 1 ? 's' : '');
                $booking->total_days = $totalDaysAndNights;
                return $booking;
            });

            return response()->json(['res' => true, 'msg' => 'Completed Bookings retrieved successfully', 'data' => $resultBookings], 200);

        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function fetchTaxes()
    {
        $gstDetails = Helper::getConfig('gst');
        $tcsDetails = Helper::getConfig('tcs');
        $data = [
            "gst" => $gstDetails,
            "tcs" => $tcsDetails
        ];
        return response()->json(['res' => true, 'msg' => '', 'data' => $data], 200);
    }

    public function vendorBookingList()
    {
        try {
            $userId = auth()->id();
            if (!$userId) {
                return response()->json(['error' => 'Unauthorized'], 401);
            }

            $vendorBookingList = $this->bookingService->getBookingsByVendor($userId);
            $currentDate = now()->toDateString(); 
            $filteredBookings = $vendorBookingList->map(function ($booking) use ($currentDate) {
                
                if ($booking->booking_status == 0) {
                    $booking->booking_status = 'In process';
                } elseif ($booking->booking_status == 1) {
                    
                    if ($booking->first_booking_date <= $currentDate && $booking->last_booking_date >= $currentDate) {
                        $booking->booking_status = 'Ongoing';
                    } elseif ($booking->first_booking_date > $currentDate) {
                        $booking->booking_status = 'Upcoming';
                    }elseif ($booking->updated_at > $booking->created_at) {
                        $booking->booking_status = 'Modified';
                    }else {
                        $booking->booking_status = 'Completed';
                     }
                } elseif ($booking->booking_status == 2) {
                    $booking->booking_status = 'Completed';
                } elseif ($booking->booking_status == 3) {
                    $booking->booking_status = 'Cancelled';
                }
                
                // Check for Modified status
                
                
                return $booking;
            });
            

            return response()->json(['res' => true, 'msg' => 'Bookings retrieved successfully', 'data' => $filteredBookings], 200);

        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

}