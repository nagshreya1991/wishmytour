<?php

namespace Modules\Booking\App\Http\Services;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Modules\Booking\app\Models\Booking;
use Modules\Booking\app\Models\BookingCustomerDetails;
use Modules\Booking\app\Models\BookingRoom;
use Modules\Booking\app\Models\BookingDate;
use Modules\Booking\app\Models\BookingPassenger;
use Modules\Package\app\Models\Package;
use Illuminate\Support\Facades\DB;
class BookingService
{
    /**
     * Add a new booking.
     *
     * @param array $requestData
     * @return array
     */
    public function addBooking(array $requestData): array
    {

        try {
            $booking = Booking::create([
                'package_id' => $requestData['package_id'],
                'customer_id' => auth()->id(),
                'add_on_id' => $requestData['add_on_id'] ?? null,
                'booking_status' => $requestData['booking_status'], //In process ->0
            ]);

            $bookingRooms = [];
            $bookingPassengers = [];
            foreach ($requestData['rooms'] as $room) {
                $bookingRoom = new BookingRoom([
                    'package_id' => $requestData['package_id'],
                    'room_no' => $room['room_no'] ?? null,
                    'adults' => $room['adults'] ?? null,
                    'children' => $room['children'] ?? null,
                ]);
                $booking->rooms()->save($bookingRoom);

                if (isset($room['passengers'])) {
                    foreach ($room['passengers'] as $passenger) {
                        $bookingPassenger = new BookingPassenger([
                            'booking_id' => $booking->id,
                            'package_id' => $requestData['package_id'],
                            'title' => $passenger['title'],
                            'first_name' => $passenger['first_name'] ?? null,
                            'last_name' => $passenger['last_name'] ?? null,
                            'dob' => $passenger['dob'] ?? null,
                            'gender' => $passenger['gender'] ?? null,
                            'is_adult' => $passenger['is_adult'] ?? 0,
                        ]);
                        $bookingRoom->passengers()->save($bookingPassenger);
                        $bookingPassengers[] = $bookingPassenger;
                    }
                }
                $bookingRooms[] = $bookingRoom;
            }

            // Handle Booking Seat Availability data
            $bookingDates = [];
            if (isset($requestData['seats'])) {
                foreach ($requestData['seats'] as $seat) {
                    $bookingDates[] = new BookingDate([
                        'package_id' => $requestData['package_id'],
                        'booking_date' => $seat['booking_date'] ?? null,
                        'cost' => $seat['cost'] ?? null,
                    ]);
                }
                $booking->dates()->saveMany($bookingDates);
            }

            // Handle Customer Details
            $bookingCustomer = new BookingCustomerDetails([
                'package_id' => $requestData['package_id'],
                'name' => $requestData['customer_name'] ?? null,
                'address' => $requestData['customer_address'] ?? null,
                'email' => $requestData['customer_email'] ?? null,
                'phone_number' => $requestData['customer_phone_number'] ?? null,
                'state_id' => $requestData['customer_state_id'] ?? null,
                'pan_number' => $requestData['customer_pan_number'] ?? null,
                'booking_for' => $requestData['customer_booking_for'] ?? null,
            ]);
            $booking->customer()->save($bookingCustomer);

            return [
                'res' => true,
                'msg' => 'Booking added successfully',
                'data' => [
                    'booking' => $booking,
                    'rooms' => $bookingRooms,
                    'passengers' => $bookingPassengers,
                    'dates' => $bookingDates,
                    'customer' => $bookingCustomer,
                ],
            ];
        } catch (\Exception $e) {
            return ['res' => false, 'msg' => $e->getMessage()];
        }
    }

    public function getUpcomingBookingsForUser(int $userId)
   {
    $currentDate = now()->toDateString(); 

    return Booking::where('customer_id', $userId)
        ->leftJoin('packages', 'bookings.package_id', '=', 'packages.id')
        ->leftJoin('booking_dates', 'booking_dates.booking_id', '=', 'bookings.id') 
        ->leftJoin('vendor_details', 'packages.user_id', '=', 'vendor_details.user_id') 
        ->select(
            'bookings.id as bookings_id',
            'bookings.*',
            'packages.id as package_id',
            'packages.*',
            'vendor_details.fullname as vendor_fullname',
            DB::raw('(SELECT booking_date FROM booking_dates WHERE booking_id = bookings.id ORDER BY booking_date ASC LIMIT 1) as first_booking_date'),
            DB::raw('(SELECT booking_date FROM booking_dates WHERE booking_id = bookings.id ORDER BY booking_date DESC LIMIT 1) as last_booking_date')
        )
        ->addSelect(DB::raw('(SELECT path FROM package_gallery_images WHERE package_id = packages.id ORDER BY id ASC LIMIT 1) as first_gallery_image'))
        ->where(function ($query) use ($currentDate) {
            $query->whereRaw('date((SELECT booking_date FROM booking_dates WHERE booking_id = bookings.id ORDER BY booking_date ASC LIMIT 1)) >= ?', [$currentDate]);
        })
        ->groupBy('bookings.id', 'vendor_details.fullname') 
        ->orderBy('first_booking_date', 'asc') // Order by ascending first_booking_date
        ->get();
     }


    public function getCompletedBookingsForUser(int $userId)
    {
    $currentDate = now()->toDateString(); 
    return Booking::where('customer_id', $userId)
    ->leftJoin('packages', 'bookings.package_id', '=', 'packages.id')
    ->leftJoin('booking_dates', 'booking_dates.booking_id', '=', 'bookings.id') 
    ->leftJoin('vendor_details', 'packages.user_id', '=', 'vendor_details.user_id') 
    ->select(
        'bookings.id as bookings_id',
        'bookings.*',
        'packages.id as package_id',
        'packages.*',
        'vendor_details.fullname as vendor_fullname',
        DB::raw('(SELECT booking_date FROM booking_dates WHERE booking_id = bookings.id ORDER BY booking_date ASC LIMIT 1) as first_booking_date'),
        DB::raw('(SELECT booking_date FROM booking_dates WHERE booking_id = bookings.id ORDER BY booking_date DESC LIMIT 1) as last_booking_date')
    )
    ->addSelect(DB::raw('(SELECT path FROM package_gallery_images WHERE package_id = packages.id ORDER BY id ASC LIMIT 1) as first_gallery_image'))
    ->where(function ($query) use ($currentDate) {
        $query->whereRaw('date((SELECT booking_date FROM booking_dates WHERE booking_id = bookings.id ORDER BY booking_date ASC LIMIT 1)) < ?', [$currentDate]);
    })
    ->groupBy('bookings.id', 'vendor_details.fullname') 
    ->orderBy('first_booking_date', 'asc') // Order by ascending first_booking_date
    ->get();
    }

    public function getBookingsByVendor(int $userId)
    {
        return Booking::leftJoin('packages', 'bookings.package_id', '=', 'packages.id')
        ->leftJoin('booking_dates', 'booking_dates.booking_id', '=', 'bookings.id')
        ->leftJoin('booking_customer_details', 'bookings.id', '=', 'booking_customer_details.booking_id')
        ->select(
            'bookings.id as bookings_id',
            'bookings.*',
            'packages.id as package_id',
            'packages.name as package_name',
            'booking_customer_details.*',
            DB::raw('(SELECT MIN(booking_date) FROM booking_dates WHERE booking_id = bookings.id) as first_booking_date'),
            DB::raw('(SELECT MAX(booking_date) FROM booking_dates WHERE booking_id = bookings.id) as last_booking_date'),
            DB::raw('(SELECT MAX(cost) FROM booking_dates WHERE booking_id = bookings.id) as booking_cost'),
            DB::raw('(SELECT SUM(adults + children) FROM booking_rooms WHERE booking_id = bookings.id) as total_pax')
        )
        ->where('packages.user_id', $userId)
        ->groupBy('bookings.id', 'booking_customer_details.id')
        ->orderBy('first_booking_date', 'asc')
        ->get();
    }
    
}
