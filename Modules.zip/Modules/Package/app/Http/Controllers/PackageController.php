<?php

namespace Modules\Package\app\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Modules\Package\app\Models\Package;
use Modules\Package\app\Http\Services\PackageService;
use Illuminate\Support\Facades\Validator;
use Modules\Package\app\Models\PackageGalleryImage;
use Modules\Package\app\Models\PackageMedia;
use Modules\Package\app\Models\PackageFlight;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use Modules\Package\app\Models\PackageHotel;
use Modules\Package\app\Models\PackageHotelGalleryImage;
use Modules\Package\app\Models\City;
use Illuminate\Support\Facades\Log;
use Modules\Package\app\Models\PackageSightseeing;
use Modules\Package\app\Models\Itinerary;
use Modules\Package\app\Models\PackageTrain;
use Modules\Package\app\Models\PackageLocalTransport;
use Modules\Package\app\Models\PackageAddon;
use Modules\Package\app\Models\PackageInclusion;
use Modules\Package\app\Models\PackageExclusion;
use Modules\Package\app\Models\PackageSeatAvailability;
use Modules\Package\app\Models\TypeOfVendor;
use Modules\Package\app\Models\TourismCircuit;
use Modules\Package\app\Models\Location;
use Modules\Package\app\Models\LocationKeyword;
use Modules\Package\app\Models\Inclusion;
use Modules\Package\app\Models\Exclusion;

class PackageController extends Controller
{
    private $packageService;

    public function __construct(PackageService $packageService)
    {
        $this->packageService = $packageService;
    }

    public function addPackage(Request $request)
    {

        if (auth()->check()) {
            if (auth()->user()->user_type == 3) {

                $result = $this->packageService->addPackage($request->all());

                return response()->json($result);
            } else {
                return response()->json(['error' => 'User type not authorized to add packages'], 403);
            }
        } else {

            return response()->json(['error' => 'Unauthorized'], 401);
        }
    }

    public function editPackage(Request $request)
    {
        if (auth()->check()) {
            if (auth()->user()->user_type == 3) {
                $result = $this->packageService->editPackage($request->all());//dd($result);
                return response()->json($result);
            } else {
                return response()->json(['error' => 'User type not authorized to edit packages'], 403);
            }
        } else {
            return response()->json(['error' => 'Unauthorized'], 401);
        }
    }

    public function getPackageList()
    {
        try {
            $packages = $this->packageService->getAllPackages(request());

            $packageList = $packages->map(function ($package) {
                $totalDays = $package->total_days;
                $totalNights = $package->fetchStayPlans()->sum('total_nights');
                $totalTrainNights = $package->trains()->count();
                $totalNights += $totalTrainNights;
                $totalDaysAndNights = "$totalDays days and $totalNights night" . ($totalNights > 1 ? 's' : '');



                $inclusionIds = explode(',', $package->inclusions_in_package);


                $inclusions = DB::table('package_inclusions')
                    ->whereIn('id', $inclusionIds)
                    ->select(['name'])
                    ->get();


                $themesIds = explode(',', $package->themes_id);


                $themes = DB::table('themes')
                    ->whereIn('id', $themesIds)
                    ->select(['name', 'image', 'icon'])
                    ->get();

                //$stayPlan = $this->prepareStayPlan($package->stay_plan);

                return [
                    'package_id' => $package->id,
                    'vendor_name' => $package->vendor_name,
                    'featured' => $package->featured,
                    'package_name' => $package->name,
                    'total_days' => $totalDaysAndNights,
                    'total_days_count' => (int)$totalDays,
                    'total_nights_count' => (int)$totalNights,
                    'total_train_nights_count' => (int)$totalTrainNights,
                    'starting_price' => round($package->starting_price),
                    'state_name' => $package->state_name,
                    'cities_name' => $package->destination_city_name,
                    'origin_city_name'=> $package->origin_city_name,
                    'transportation_name' => $package->transportation->name ?? null,
                    'hotel_star' => $package->hotel_star_id,
                    'religion' => $package->religion->name ?? null,
                    'trip' => $package->trip->name,
                    'type_of_tour_packages' => $package->type_name,
                    'themes' => $themes,
                    'featured_image_path' => $package->first_gallery_image,
                    'inclusions_in_package' => $inclusions,
                    'overview' => $package->overview,
                    // 'inclusions_list' => $package->inclusions_list,
                    // 'exclusions_list' => $package->exclusions_list,
                    'terms_and_condition' => $package->terms_and_condition,
                    'stay_plan' => $package->fetchStayPlans(),
                    'is_transport' => $package->is_transport,
                    'is_flight' => $package->is_flight,
                    'is_train' => $package->is_train,
                    'is_hotel' => $package->is_hotel,
                    'is_meal' => $package->is_meal,
                    'is_sightseeing' => $package->is_sightseeing,
                    'created_at' => date($package->created_at),
                ];
            });

            if ($packageList->isEmpty()) {
                return response()->json(['res' => false, 'msg' => 'No packages found'], 404);
            }

            return response()->json(['res' => true, 'msg' => 'Packages retrieved successfully', 'data' => $packageList], 200);
        } catch (\Exception $e) {

            return response()->json(['res' => false, 'msg' => $e->getMessage()], 500);
        }
    }


    public function packageDetails($id)
    {
        try {
            $package = $this->packageService->getPackageDetails($id);


            if (!$package) {
                return response()->json(['res' => false, 'msg' => 'Package not found'], 404);
            }


            // $galleryImages = $package->gallery_images ?? [];
            $galleryImages = [];
            foreach ($package->gallery_images as $image) {
                $galleryImages[] = [
                    'id' => $image['id'],
                    'path' => $image['path'],
                ];
            }
            $mediaLinks = $package->mediaLinks ?? [];
            $addons = $package->addons ?? [];
            $seatAvailability = $package->seatAvailability ?? [];
            $itinerary = $package->itinerary ?? [];
            $inclusionList = $package->inclusions ?? [];
            $exclusionList = $package->exclusions ?? [];
            $totalDays = $package->total_days;
            $totalNights = $package->stay_plan->sum('total_nights');
            $totalTrainNights = $package->trains()->count();
            $totalNights += $totalTrainNights;
            $totalDaysAndNights = "$totalDays days and $totalNights night" . ($totalNights > 1 ? 's' : '');


            $inclusionIds = explode(',', $package->inclusions_in_package);


            $inclusions = DB::table('package_inclusions')
                ->whereIn('id', $inclusionIds)
                ->select(['name'])
                ->get();


            $themesIds = explode(',', $package->themes_id);


            $themes = DB::table('themes')
                ->whereIn('id', $themesIds)
                ->select(['id', 'name', 'image', 'icon'])
                ->get();

            $stayPlan = $package->stay_plan;

            $transformedPackage = [
                'package_id' => $package->id,
                'vendor_name' => $package->vendor_name,
                'package_name' => $package->name,
                'total_days' => $totalDaysAndNights,
                'total_days_count' => (int)$totalDays,
                'total_nights_count' => (int)$totalNights,
                'starting_price' => isset($package->starting_price) ? round($package->starting_price) : null,
                'origin' => $package->origin_city_id,
                'destination_state_id' => $package->destination_state_id,
                'state_name' => $package->state_name,
                'destination_city_id' => $package->destination_city_id,
                'cities_name' => $package->cities_name,
                'keywords' => $package->keywords,
                'transportation_name' => isset($package->transportation->name) ? ($package->transportation->name) : null,
                'hotel_star' => isset($package->hotel_star_id) ? ($package->hotel_star_id) : null,
                'religion' => isset($package->religion->name) ? ($package->religion->name) : null,
                'trip_id' => $package->trip_id,
                'trip' => $package->trip->name,
                'type_of_tour_packages_id' => $package->type_of_tour_packages_id,
                'type_of_tour_packages' => $package->type_name,
                'themes' => $themes,
                'featured_image_path' => $package->featured_image_path,
                'inclusions_in_package' => $inclusions,
                'overview' => $package->overview,
                'inclusions_list' => $inclusionList,
                'exclusions_list' => $exclusionList,
                'terms_and_condition' => $package->terms_and_condition,
                'payment_policy' => $package->payment_policy,
                'cancellation_policy' => $package->cancellation_policy,
                'child_discount' => $package->child_discount,
                'single_occupancy_cost' => $package->single_occupancy_cost,
                'offseason_from_date' => $package->offseason_from_date,
                'offseason_to_date' => $package->offseason_to_date,
                'offseason_price' => $package->offseason_price,
                'onseason_from_date' => $package->onseason_from_date,
                'onseason_to_date' => $package->onseason_to_date,
                'onseason_price' => $package->onseason_price,
                'total_seat' => $package->total_seat,
                'bulk_no_of_pax' => $package->bulk_no_of_pax,
                'pax_discount_percent' => $package->pax_discount_percent,
                'created_at' => date($package->created_at),
                'gallery_images' => $galleryImages,
                'stay_plan' => $stayPlan,

                'media_link' => $mediaLinks,
                'addons' => $addons,
                'seat_availability' => $seatAvailability,
                'tour_circuit' => $package->tour_circuit,
                'location' => $package->location,
                'status' => $package->status,
                'is_transport' => $package->is_transport,
                'is_flight' => $package->is_flight,
                'is_train' => $package->is_train,
                'is_hotel' => $package->is_hotel,
                'is_meal' => $package->is_meal,
                'is_sightseeing' => $package->is_sightseeing,
                'triple_sharing_discount' => $package->triple_sharing_discount,
                'itinerary' => $this->transformItinerary($package->itinerary),

            ];

            return response()->json(['res' => true, 'data' => $transformedPackage], 200);
        } catch (\Exception $e) {
            Log::error('Error occurred while fetching package details: ' . $e->getMessage());

            return response()->json(['res' => false, 'msg' => $e->getMessage()], 500);
        }
    }

    private function transformItinerary($itineraries)
    {

        return $itineraries->map(function ($itinerary) {
            $flights = $itinerary->flight ?? [];
            $trains = $itinerary->train ?? [];
            $local_transport = $itinerary->local_transport ?? [];
            $sightseeing = $itinerary->sightseeing ?? [];
            $hotels = $itinerary->hotel ?? [];
            $transformedHotels = [];
            foreach ($hotels as $hotel) {
                // Get hotel gallery images for each hotel
                //$hotelGalleryImages = PackageHotelGalleryImage::where('hotel_id', $hotel->id)->pluck('id','path')->toArray();
                $hotelGalleryImages = PackageHotelGalleryImage::where('hotel_id', $hotel->id)
                    ->select('id', 'path')
                    ->pluck('path', 'id')
                    ->toArray();

                $galleryImages = [];
                foreach ($hotelGalleryImages as $id => $path) {
                    $galleryImages[] = [
                        'id' => $id,
                        'path' => $path,
                    ];
                }


                $transformedHotels[] = [
                    'hotel_id' => $hotel->id,
                    'hotel_name' => $hotel->name,
                    'star' => $hotel->rating,
                    'hotel_gallery' => $galleryImages,
                ];
            }


            $transformedFlights = [];
            foreach ($flights as $flight) {
                $departCity = City::find($flight['depart_destination']);
                $arriveCity = City::find($flight['arrive_destination']);

                $transformedFlights[] = [
                    'id' => $flight['id'],
                    'depart_destination' => [
                        'id' => $flight['depart_destination'],
                        'name' => $departCity ? $departCity->city : null,
                    ],
                    'arrive_destination' => [
                        'id' => $flight['arrive_destination'],
                        'name' => $arriveCity ? $arriveCity->city : null,
                    ],
                    'depart_datetime' => $flight['depart_datetime'] ?? null,
                    'arrive_datetime' => $flight['arrive_datetime'] ?? null,
                ];
            }
            // Transform trains
            $transformedTrains = [];
            foreach ($trains as $train) {
                $departCity = City::find($train['from_station']);
                $arriveCity = City::find($train['to_station']);

                $transformedTrains[] = [
                    'id' => $train['id'],
                    'depart_destination' => [
                        'id' => $train['from_station'],
                        'name' => $departCity ? $departCity->city : null,
                    ],
                    'arrive_destination' => [
                        'id' => $train['to_station'],
                        'name' => $arriveCity ? $arriveCity->city : null,
                    ],
                    'train_name' => $train['train_name'] ?? null,
                    'train_number' => $train['train_number'] ?? null,
                    'class' => $train['class'] ?? null,
                    'depart_datetime' => $train['depart_datetime'] ?? null,
                    'arrive_datetime' => $train['arrive_datetime'] ?? null,
                ];
            }
            return [
                'itinerary_id' => $itinerary->id,
                'day' => $itinerary->day,
                'place_name' => $itinerary->place_name,
                'itinerary_title' => $itinerary->itinerary_title,
                'itinerary_description' => $itinerary->itinerary_description,
                'meal' => $itinerary->meal,
                'flights' => $transformedFlights,
                //'trains' => $trains,
                'trains' => $transformedTrains,
                'local_transport' => $local_transport,
                'sightseeing' => $sightseeing,
                'hotels' => $transformedHotels,
            ];
        });
    }

    //****************************DELETE FUNCTIONS****************** */
    public function deleteGalleryImages($id)
    {


        try {
            $galleryImage = PackageGalleryImage::findOrFail($id);
            $galleryImage->delete();

            return response()->json(['res' => true, 'msg' => 'Gallery image deleted successfully'], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json(['res' => false, 'msg' => 'Not found'], 404);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Internal Server Error'], 500);
        }

    }

    public function deleteMediaLink($id)
    {

        try {
            $media = PackageMedia::findOrFail($id);
            $media->delete();

            return response()->json(['res' => true, 'msg' => 'Media deleted successfully'], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json(['res' => false, 'msg' => 'Not found'], 404);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Internal Server Error'], 500);
        }

    }

    public function deleteFlight($id)
    {

        try {
            $flight = PackageFlight::findOrFail($id);
            $flight->delete();

            return response()->json(['res' => true, 'msg' => 'Flight information deleted successfully'], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json(['res' => false, 'msg' => 'Not found'], 404);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Internal Server Error'], 500);
        }

    }

    public function deleteSightseeing($id)
    {

        try {
            $sightseeing = PackageSightseeing::findOrFail($id);
            $sightseeing->delete();

            return response()->json(['res' => true, 'msg' => 'Sightseeing information deleted successfully'], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json(['res' => false, 'msg' => 'Not found'], 404);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Internal Server Error'], 500);
        }
    }


    public function removeMeal($id)
    {
        try {

            $itinerary = Itinerary::findOrFail($id);


            $itinerary->update(['meal' => null]);

            return response()->json(['res' => true, 'msg' => 'Meal removed successfully'], 200);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Failed to remove meal', 'details' => $e->getMessage()], 500);
        }
    }

    public function deleteHotel($id)
    {

        try {
            $hotel = PackageHotel::findOrFail($id);
            $hotel->delete();

            return response()->json(['res' => true, 'msg' => 'Hotel information deleted successfully'], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json(['res' => false, 'msg' => 'Not found'], 404);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Internal Server Error'], 500);
        }
    }

    public function deleteHotelGallery($id)
    {

        try {
            $hotelG = PackageHotelGalleryImage::findOrFail($id);
            $hotelG->delete();

            return response()->json(['res' => true, 'msg' => 'Image deleted successfully'], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json(['res' => false, 'msg' => 'Not found'], 404);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Internal Server Error'], 500);
        }
    }

    public function deleteTrain($id)
    {

        try {
            $train = PackageTrain::findOrFail($id);
            $train->delete();

            return response()->json(['res' => true, 'msg' => 'Train information deleted successfully'], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json(['res' => false, 'msg' => 'Not found'], 404);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Internal Server Error'], 500);
        }
    }

    public function deleteLocalTransport($id)
    {
        try {
            $localtransport = PackageLocalTransport::findOrFail($id);
            $localtransport->delete();

            return response()->json(['res' => true, 'msg' => 'Local transport information deleted successfully'], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json(['res' => false, 'msg' => 'Not found'], 404);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Internal Server Error'], 500);
        }
    }

    public function deleteAddons($id)
    {

        try {
            $addon = PackageAddon::findOrFail($id);
            $addon->delete();

            return response()->json(['res' => true, 'msg' => 'Addon information deleted successfully'], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json(['res' => false, 'msg' => 'List not found'], 404);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Internal Server Error'], 500);
        }
    }

    public function deleteInclusionList($id)
    {
        try {
            $inclusion = PackageInclusion::findOrFail($id);
            $inclusion->delete();

            return response()->json(['res' => true, 'msg' => 'Inclusion deleted successfully.'], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json(['res' => false, 'msg' => 'List not found'], 404);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Internal Server Error'], 500);
        }
    }

    public function deleteExclusionList($id)
    {
        try {
            $exclusion = ExclusionList::findOrFail($id);
            $exclusion->delete();

            return response()->json(['res' => true, 'msg' => 'Exclusion deleted successfully'], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json(['res' => false, 'msg' => 'List not found'], 404);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Internal Server Error'], 500);
        }
    }

    public function deleteItinerary($id)
    {
        try {
            $itinerary = Itinerary::findOrFail($id);
            $itinerary->delete();

            return response()->json(['res' => true, 'msg' => 'Itinerary deleted successfully'], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json(['res' => false, 'msg' => 'List not found'], 404);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Internal Server Error'], 500);
        }
    }

    public function deleteSeatavailability($id)
    {
        try {
            $seat = PackageSeatAvailability::findOrFail($id);
            $seat->delete();

            return response()->json(['res' => true, 'msg' => 'Seat deleted successfully.'], 200);
        } catch (ModelNotFoundException $e) {
            return response()->json(['res' => false, 'msg' => 'List not found'], 404);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Internal Server Error'], 500);
        }
    }


    public function bestsellingList()
    {
        try {
            $packageCounts = $this->packageService->getPackageCountsByState(request());

            return response()->json(['res' => true, 'msg' => 'Package counts retrieved successfully', 'data' => $packageCounts], 200);
        } catch (\Exception $e) {
            // Handle exceptions, log, or return an error response
            return response()->json(['res' => false, 'msg' => 'Internal Server Error'], 500);
        }
    }

    public function popularDestination()
    {
        try {
            $packageCounts = $this->packageService->getPopularDestination(request());

            return response()->json(['res' => true, 'msg' => 'Package  retrieved successfully', 'data' => $packageCounts], 200);
        } catch (\Exception $e) {
            // Handle exceptions, log, or return an error response
            return response()->json(['res' => false, 'msg' => 'Internal Server Error'], 500);
        }
    }

    public function durationList()
    {
        try {
            $result = DB::table('packages')->orderBy('total_days')->distinct()->get(['total_days']);

            return response()->json(['res' => true, 'msg' => 'Duration list retrieved successfully', 'data' => $result], 200);
        } catch (\Exception $e) {
            // Handle exceptions, log, or return an error response
            return response()->json(['res' => false, 'msg' => 'Internal Server Error'], 500);
        }
    }

    public function destinationsByTheme()
    {
        try {
            $package = $this->packageService->getdestinationsByTheme(request());

            return response()->json(['res' => true, 'msg' => 'Package  retrieved successfully', 'data' => $package], 200);
        } catch (\Exception $e) {
            // Handle exceptions, log, or return an error response
            return response()->json(['res' => false, 'msg' => 'Internal Server Error'], 500);
        }
    }

    public function filterPackages(Request $request)
    {
        try {
            $filters = $request->all();

            $filteredPackages = $this->packageService->filterPackages($filters);

            $processedPackages = $filteredPackages->map(function ($package) {
                $totalDays = $package->total_days;
                $totalNights = $package->fetchStayPlans()->sum('total_nights');
                $totalTrainNights = $package->trains()->count();
                $totalNights += $totalTrainNights;
                $totalDaysAndNights = "$totalDays days and $totalNights night" . ($totalNights > 1 ? 's' : '');



                $inclusionIds = explode(',', $package->inclusions_in_package);


                $inclusions = DB::table('package_inclusions')
                    ->whereIn('id', $inclusionIds)
                    ->select(['name'])
                    ->get();


                $themesIds = explode(',', $package->themes_id);


                $themes = DB::table('themes')
                    ->whereIn('id', $themesIds)
                    ->select(['name', 'image', 'icon'])
                    ->get();

                return [
                    'package_id' => $package->id,
                    'vendor_name' => $package->vendor_name,
                    'featured' => $package->featured,
                    'package_name' => $package->name,
                    'total_days' => $totalDaysAndNights,
                    'total_days_count' => (int)$totalDays,
                    'total_nights_count' => (int)$totalNights,
                    'total_train_nights_count' => (int)$totalTrainNights,
                    'duration' => $totalDays,
                    'starting_price' => round($package->starting_price),
                    'state_name' => $package->state_name,
                    'cities_name' => $package->destination_city_name,
                    'origin_city_name'=> $package->origin_city_name,
                    'keywords' => $package->keywords,
                    'transportation_name' => $package->transportation->name ?? null,
                    'hotel_star' => $package->hotel_star_id,
                    'religion' => $package->religion->name ?? null,
                    'trip' => $package->trip->name,
                    'type_of_tour_packages' => $package->type_name,
                    'themes' => $themes,
                    'featured_image_path' => $package->featured_image_path,
                    'inclusions_in_package' => $inclusions,
                    'overview' => $package->overview,
                    'location' => $package->location,
                    //  'exclusions_list' => $package->exclusions_list,
                    'terms_and_condition' => $package->terms_and_condition,
                    'stay_plan' => $package->fetchStayPlans(),
                    'created_at' => date($package->created_at),
                    'is_transport' => $package->is_transport,
                    'is_flight' => $package->is_flight,
                    'is_train' => $package->is_train,
                    'is_hotel' => $package->is_hotel,
                    'is_meal' => $package->is_meal,
                    'is_sightseeing' => $package->is_sightseeing,
                ];
            });

            return response()->json(['res' => true, 'msg' => 'Packages filtered successfully', 'data' => $processedPackages], 200);
        } catch (\Exception $e) {

            return response()->json(['res' => false, 'msg' => $e->getMessage()], 500);
        }
    }


    public function getFrontPackageList()
    {
        try {
            $query = Package::with([
                'religion',
                'themes',
                'transportation',
                'typeoftourpackages',
                'trip',
                'stayPlans'
            ])
                ->join('states', 'packages.destination_state_id', '=', 'states.id')
                ->leftjoin('cities', 'packages.destination_city_id', '=', 'cities.id')
                ->leftjoin('type_of_tour_packages', 'packages.type_of_tour_packages_id', '=', 'type_of_tour_packages.id')
                ->leftjoin('users', 'packages.user_id', '=', 'users.id')
                ->select(
                    'packages.*',
                    'states.name as state_name',
                    'cities.city as cities_name',
                    'type_of_tour_packages.name as type_name',
                    'users.name as vendor_name'
                )
                ->where('status', 1);


            $packages = $query->latest('packages.created_at')->limit(10)->get();

            $formattedPackages = [];

            foreach ($packages as $package) {

                $featuredImage = PackageGalleryImage::where('package_id', $package->id)->first();

                $inclusionIds = explode(',', $package->inclusions_in_package);


                $inclusions = DB::table('package_inclusions')
                    ->whereIn('id', $inclusionIds)
                    ->select(['name'])
                    ->get();


                $themesIds = explode(',', $package->themes_id);


                $themes = DB::table('themes')
                    ->whereIn('id', $themesIds)
                    ->select(['name', 'image', 'icon'])
                    ->get();

                $totalDays = $package->total_days;
                $totalNights = $package->fetchStayPlans()->sum('total_nights');
                $totalDaysAndNights = "$totalDays days and $totalNights night" . ($totalNights > 1 ? 's' : '');


                $formattedPackages[] = [
                    'package_id' => $package->id,
                    'featured_image_path' => $featuredImage ? $featuredImage->path : null,
                    'package_name' => $package->name,
                    'inclusionIds' => $inclusions,
                    'total_days' => $totalDaysAndNights,
                    'total_days_count' => (int)$totalDays,
                    'total_nights_count' => (int)$totalNights,
                    'themes' => $themes
                ];
            }


            $chunkedPackages = array_chunk($formattedPackages, 2);
            return response()->json(['res' => true, 'msg' => 'Packages retrieved successfully', 'data' => $chunkedPackages], 200);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Internal Server Error'], 500);
        }
    }


    public function stateList(Request $request)
    {
        try {
            $states = $this->packageService->getStateList($request);
            return response()->json(['res' => true, 'msg' => 'Data retrieved successfully', 'data' => $states], 200);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Internal Server Error'], 500);
        }
    }

    public function cityList(Request $request)
    {
        try {
            $cities = $this->packageService->getCityList($request);
            return response()->json(['res' => true, 'msg' => 'Data retrieved successfully', 'data' => $cities], 200);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Internal Server Error'], 500);
        }
    }

    public function TransportationList(Request $request)
    {
        try {
            $transportationList = $this->packageService->getTransportationList($request);
            return response()->json(['res' => true, 'msg' => 'Data retrieved successfully', 'data' => $transportationList], 200);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Internal Server Error'], 500);
        }
    }

    public function tripList(Request $request)
    {
        try {
            $tripList = $this->packageService->gettripList($request);
            return response()->json(['res' => true, 'msg' => 'Data retrieved successfully', 'data' => $tripList], 200);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Internal Server Error'], 500);
        }
    }

    public function typeOfTourPackagesList(Request $request)
    {
        try {
            $typeOfTourPackagesList = $this->packageService->gettypeOfTourPackagesList($request);
            return response()->json(['res' => true, 'msg' => 'Data retrieved successfully', 'data' => $typeOfTourPackagesList], 200);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Internal Server Error'], 500);
        }
    }
    public function typeOfVendorList(Request $request)
    {
        try {
            $typeOfVendorList = $this->packageService->gettypeOfVendorList($request);
            return response()->json(['res' => true, 'msg' => 'Data retrieved successfully', 'data' => $typeOfVendorList], 200);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Internal Server Error'], 500);
        }
    }
    public function themesList(Request $request)
    {
        try {
            $themesList = $this->packageService->getthemesList($request);
            return response()->json(['res' => true, 'msg' => 'Data retrieved successfully', 'data' => $themesList], 200);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Internal Server Error'], 500);
        }
    }

    public function religionList(Request $request)
    {
        try {
            $religionList = $this->packageService->getreligionList($request);
            return response()->json(['res' => true, 'msg' => 'Data retrieved successfully', 'data' => $religionList], 200);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Internal Server Error'], 500);
        }
    }

    public function totaldaysRange(Request $request)
    {
        try {
            $totalday = $this->packageService->gettotalday($request);
            return response()->json(['res' => true, 'msg' => 'Data retrieved successfully', 'data' => $totalday], 200);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Internal Server Error'], 500);
        }
    }

    public function startingpriceRange(Request $request)
    {
        try {
            $startingpriceRange = $this->packageService->getstartingpriceRange($request);
            return response()->json(['res' => true, 'msg' => 'Data retrieved successfully', 'data' => $startingpriceRange], 200);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Internal Server Error'], 500);
        }
    }

    public function comparePackagelist(Request $request)
    {
        try {
            $packageIds = $request->input('package_ids', []);

            if (count($packageIds) > 4) {
                return response()->json(['res' => false, 'msg' => 'You can only compare up to 4 packages.'], 400);
            }

            $compareList = $this->packageService->getComparePackagelist($packageIds);

            return response()->json(['res' => true, 'msg' => 'Data retrieved successfully', 'data' => $compareList], 200);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Internal Server Error'], 500);
        }
    }

    public function vendorPackageList()
    {
        try {
            $packages = $this->packageService->vendorPackageList(request());


            $packageList = $packages->map(function ($package) {
                $totalDays = $package->total_days;
                $totalNights = $package->fetchStayPlans()->sum('total_nights');
                $totalDaysAndNights = "$totalDays days and $totalNights night" . ($totalNights > 1 ? 's' : '');


                $inclusionIds = explode(',', $package->inclusions_in_package);


                $inclusions = DB::table('package_inclusions')
                    ->whereIn('id', $inclusionIds)
                    ->select(['name'])
                    ->get();


                $themesIds = explode(',', $package->themes_id);


                $themes = DB::table('themes')
                    ->whereIn('id', $themesIds)
                    ->select(['name', 'image', 'icon'])
                    ->get();

                //$stayPlan = $this->prepareStayPlan($package->stay_plan);

                if ($package->status == 0) {
                    $status = "Inactive";
                } elseif ($package->status == 1) {
                    $status = "Active";
                } elseif ($package->status == 2) {
                    $status = "Approval Pending";
                } elseif ($package->status == 3) {
                    $status = "Archive";
                } else {

                }
                $originCityName = City::where('id', $package->origin_city_id)->value('city');
                return [
                    'package_id' => $package->id,
                    'vendor_name' => $package->vendor_name,
                    'featured' => $package->featured,
                    'package_name' => $package->name,
                    'total_days' => $totalDaysAndNights,
                    'total_days_count' => (int)$totalDays,
                    'total_nights_count' => (int)$totalNights,
                    'starting_price' => round($package->starting_price),
                    'state_name' => $package->state_name,
                    'cities_name' => $package->cities_name,
                    'transportation_name' => $package->transportation->name ?? null,
                    'hotel_star' => $package->hotel_star_id,
                    'religion' => $package->religion->name ?? null,
                    'trip' => $package->trip->name,
                    'type_of_tour_packages' => $package->type_name,
                    'themes' => $themes,
                    'featured_image_path' => $package->featured_image_path,
                    'inclusions_in_package' => $inclusions,
                    'overview' => $package->overview,
                    'origin' => $originCityName,
                    // 'inclusions_list' => $package->inclusions_list,
                    // 'exclusions_list' => $package->exclusions_list,
                    'terms_and_condition' => $package->terms_and_condition,
                    'stay_plan' => $package->fetchStayPlans(),
                    'is_transport' => $package->is_transport,
                    'is_flight' => $package->is_flight,
                    'is_train' => $package->is_train,
                    'is_hotel' => $package->is_hotel,
                    'is_meal' => $package->is_meal,
                    'is_sightseeing' => $package->is_sightseeing,
                    'created_at' => date('d M, Y', strtotime($package->created_at)),
                    'status' => $status,
                ];
            });

            if ($packageList->isEmpty()) {
                return response()->json(['res' => false, 'msg' => 'No packages found'], 404);
            }

            return response()->json(['res' => true, 'msg' => 'Packages retrieved successfully', 'data' => $packageList], 200);
        } catch (\Exception $e) {

            return response()->json(['res' => false, 'msg' => $e->getMessage()], 500);
        }
    }


    public function markStatus(Request $request)
    {
        try {
            $packageIds = $request->input('package_ids', []);
            $status = $request->input('status', '');

            $this->packageService->updatePackageStatus($packageIds, $status);

            return response()->json(['res' => true, 'msg' => 'Status updated successfully'], 200);
        } catch (\Exception $e) {

            return response()->json(['res' => false, 'msg' => 'Internal Server Error'], 500);
        }
    }

    public function addonListByPackage(Request $request)
    {
        $packageId = $request->input('package_id');
        $addons = $this->packageService->getAddonsByPackageId($packageId);
        return response()->json(['res' => true, 'msg' => '', 'data' => $addons]);
    }

    public function seatAvailabilityByPackage(Request $request)
    {
        // dd("dasd");
        $packageId = $request->input('package_id');
        $seatAvailability = $this->packageService->getseatAvailability($packageId);
        return response()->json(['res' => true, 'msg' => '', 'seatAvailability' => $seatAvailability]);
    }

    public function exploreDestinationCount(Request $request)
    {
        try {
            $packageCounts = Package::groupBy('location')
                ->select('location', \DB::raw('COUNT(*) as package_count'))
                ->get();


            $totalLocations = $packageCounts->count();

            return response()->json([
                'res' => true,
                'msg' => 'Destination counts retrieved successfully',
                'data' => [
                    'package_counts' => $packageCounts,
                    'total_locations' => $totalLocations
                ]
            ], 200);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Internal Server Error'], 500);
        }
    }

    /**
     * Fetches all tourism circuits from the database.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function fetchTourismCircuits(): \Illuminate\Http\JsonResponse
    {
        try {
            $tourismCircuits = TourismCircuit::all();

            if ($tourismCircuits->isEmpty()) {
                return response()->json(['res' => true, 'msg' => 'No tourism circuits found', 'data' => []], 200);
            }

            return response()->json(['res' => true, 'msg' => 'Tourism circuits retrieved successfully', 'data' => $tourismCircuits], 200);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Failed to retrieve tourism circuits', 'error' => $e->getMessage()], 500);
        }
    }

    /**
     * Fetches all locations from the database.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function fetchLocations(): \Illuminate\Http\JsonResponse
    {
        try {
            $locations = Location::all();

            if ($locations->isEmpty()) {
                return response()->json(['res' => true, 'msg' => 'No locations found', 'data' => []], 200);
            }

            return response()->json(['res' => true, 'msg' => 'Locations retrieved successfully', 'data' => $locations], 200);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Failed to retrieve locations', 'error' => $e->getMessage()], 500);
        }
    }

    /**
     * Fetches keywords associated with a specific location.
     *
     * @param int $locationId
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function fetchLocationKeywords(int $locationId, Request $request): \Illuminate\Http\JsonResponse
    {
        try {
            // Find the location
            $location = Location::findOrFail($locationId);

            // Retrieve keywords associated with the location
            $query = LocationKeyword::where('location_id', $locationId);

            if ($request->has('sort') && $request->sort == 'true') {
                // If sort parameter is true, join with package table and count
                $query->select('location_keywords.*', DB::raw('COUNT(packages.id) as package_count'))
                    ->join('packages', function ($join) {
                        $join->on(DB::raw('FIND_IN_SET(location_keywords.name, packages.keywords)'), '>', DB::raw('0'));
                    })
                    ->groupBy('location_keywords.id')
                    ->orderBy('package_count', 'desc');
            }

            $keywords = $query->pluck('name');

            return response()->json(['res' => true, 'msg' => 'Keywords retrieved successfully', 'data' => $keywords], 200);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Failed to retrieve keywords', 'error' => $e->getMessage()], 500);
        }
    }

    /**
     * Fetches keywords associated with a specific location.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function fetchAllKeywords(Request $request): \Illuminate\Http\JsonResponse
    {
        try {
            $query = LocationKeyword::query();
            $locationId = $request->location_id ?? null;

            if ($request->has('sort') && $request->sort == 'true') {
                // If sort parameter is true, join with package table and count
                $query->join('packages', function ($join) {
                        $join->on(DB::raw('FIND_IN_SET(location_keywords.name, packages.keywords)'), '>', DB::raw('0'));
                    })
                    ->leftJoin('locations', 'location_keywords.location_id', '=', 'locations.id')
                    ->select('location_keywords.*', DB::raw('COUNT(DISTINCT(packages.id)) as package_count'));
            }
            if ($locationId !== null) {
                $location = Location::findOrFail($locationId);
                $query->where('location_keywords.location_id', $locationId);
                $query->where('packages.location', $location->name);
            }
            $query->groupBy('location_keywords.id', 'location_keywords.location_id', 'location_keywords.name')->orderBy('package_count', 'desc');
            $keywords = $query->get()->unique('name')->values()->all();
            //$keywords = $query->get();

            return response()->json(['res' => true, 'msg' => 'Keywords retrieved successfully', 'data' => $keywords], 200);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Failed to retrieve keywords', 'error' => $e->getMessage()], 500);
        }
    }

    /**
     * Fetches keywords associated with a specific location.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function fetchSearchKeywords(Request $request): \Illuminate\Http\JsonResponse
    {
        try {
            $query = LocationKeyword::query();
            $locationId = $request->location_id ?? null;
            $searchKeyword = $request->search_keyword ?? null;
            // If sort parameter is true, join with package table and count
            $query->join('packages', function ($join) {
                $join->on(DB::raw('FIND_IN_SET(location_keywords.name, packages.keywords)'), '>', DB::raw('0'));
            })
                ->leftJoin('locations', 'location_keywords.location_id', '=', 'locations.id')
                ->select('location_keywords.*', DB::raw('COUNT(DISTINCT(packages.id)) as package_count'));

            if ($locationId !== null) {
                $location = Location::findOrFail($locationId);
                $query->where('location_keywords.location_id', $locationId);
                $query->where('packages.location', $location->name);
            }
            if ($searchKeyword !== null) {
                $query->where('location_keywords.name', 'like', '%' . $searchKeyword . '%');
            }
            $query->groupBy('location_keywords.id', 'location_keywords.location_id', 'location_keywords.name')->orderBy('package_count', 'desc');
            $keywords = $query->get()->unique('name')->values()->all();
            //$keywords = $query->get();

            return response()->json(['res' => true, 'msg' => 'Keywords retrieved successfully', 'data' => $keywords], 200);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Failed to retrieve keywords', 'error' => $e->getMessage()], 500);
        }
    }

    /**
     * Fetches all inclusions from the database.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function fetchInclusions(): \Illuminate\Http\JsonResponse
    {
        try {
            $inclusions = Inclusion::all();

            if ($inclusions->isEmpty()) {
                return response()->json(['res' => true, 'msg' => 'No inclusions found', 'data' => []], 200);
            }

            return response()->json(['res' => true, 'msg' => 'Inclusions retrieved successfully', 'data' => $inclusions], 200);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Failed to retrieve inclusions', 'error' => $e->getMessage()], 500);
        }
    }

    /**
     * Fetches all exclusions from the database.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function fetchExclusions(): \Illuminate\Http\JsonResponse
    {
        try {
            $exclusions = Exclusion::all();

            if ($exclusions->isEmpty()) {
                return response()->json(['res' => true, 'msg' => 'No exclusions found', 'data' => []], 200);
            }

            return response()->json(['res' => true, 'msg' => 'Exclusions retrieved successfully', 'data' => $exclusions], 200);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => 'Failed to retrieve exclusions', 'error' => $e->getMessage()], 500);
        }
    }

    public function getRelatedPackages($packageId)
    {
        try {
          
            $relatedPackages = $this->packageService->getRelatedPackages($packageId);
            $packageList = $relatedPackages->map(function ($package) {
                $totalDays = $package->total_days;
                $totalNights = $package->fetchStayPlans()->sum('total_nights');
                $totalDaysAndNights = "$totalDays days and $totalNights night" . ($totalNights > 1 ? 's' : '');
                $totalTrainNights = $package->trains()->count();


                $inclusionIds = explode(',', $package->inclusions_in_package);


                $inclusions = DB::table('package_inclusions')
                    ->whereIn('id', $inclusionIds)
                    ->select(['name'])
                    ->get();


                $themesIds = explode(',', $package->themes_id);


                $themes = DB::table('themes')
                    ->whereIn('id', $themesIds)
                    ->select(['name', 'image', 'icon'])
                    ->get();

                //$stayPlan = $this->prepareStayPlan($package->stay_plan);

                return [
                    'package_id' => $package->id,
                    'vendor_name' => $package->vendor_name,
                    'featured' => $package->featured,
                    'package_name' => $package->name,
                    'total_days' => $totalDaysAndNights,
                    'total_days_count' => (int)$totalDays,
                    'total_nights_count' => (int)$totalNights,
                    'total_train_nights_count' => (int)$totalTrainNights,
                    'starting_price' => round($package->starting_price),
                    'state_name' => $package->state_name,
                    'cities_name' => $package->cities_name,
                    'transportation_name' => $package->transportation->name ?? null,
                    'hotel_star' => $package->hotel_star_id,
                    'religion' => $package->religion->name ?? null,
                    'trip' => $package->trip->name,
                    'type_of_tour_packages' => $package->type_name,
                    'themes' => $themes,
                    'featured_image_path' => $package->first_gallery_image,
                    'inclusions_in_package' => $inclusions,
                    'overview' => $package->overview,
                    // 'inclusions_list' => $package->inclusions_list,
                    // 'exclusions_list' => $package->exclusions_list,
                    'terms_and_condition' => $package->terms_and_condition,
                    'stay_plan' => $package->fetchStayPlans(),
                    'is_transport' => $package->is_transport,
                    'is_flight' => $package->is_flight,
                    'is_train' => $package->is_train,
                    'is_hotel' => $package->is_hotel,
                    'is_meal' => $package->is_meal,
                    'is_sightseeing' => $package->is_sightseeing,
                    'created_at' => date($package->created_at),
                ];
            });

            if ($packageList->isEmpty()) {
                return response()->json(['res' => false, 'msg' => 'No packages found'], 404);
            }
            return response()->json(['res' => true, 'msg' => 'Related packages retrieved successfully', 'data' => $packageList], 200);
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => $e->getMessage()], 500);
        }
    }

}
