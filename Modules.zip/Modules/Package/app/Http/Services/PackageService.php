<?php

namespace Modules\Package\App\Http\Services;

use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Modules\Package\app\Models\Package;
use Modules\Package\app\Models\Itinerary;
use Modules\Package\app\Models\PackageGalleryImage;
use Modules\Package\app\Models\PackageFlight;
use Modules\Package\app\Models\PackageTrain;
use Modules\Package\app\Models\PackageLocalTransport;
use Modules\Package\app\Models\PackageHotel;
use Modules\Package\app\Models\PackageHotelGalleryImage;
use Modules\Package\app\Models\Themes;
use Modules\Package\app\Models\State;
use Modules\Package\app\Models\City;
use Modules\Package\app\Models\TypeOfTourPackages;
use Modules\Package\app\Models\Trip;
use Modules\Package\app\Models\Transportation;
use Modules\Package\app\Models\Religion;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Modules\Package\app\Models\PackageAddon;
use Modules\Package\app\Models\PackageMedia;
use Modules\Package\app\Models\PackageSeatAvailability;
use Modules\Package\app\Models\PackageSightseeing;
use Modules\Package\app\Models\PackageInclusion;
use Modules\Package\app\Models\PackageExclusion;
use Modules\Package\app\Models\VendorType;
use Modules\Package\app\Models\Location;
use Modules\Package\app\Models\LocationKeyword;
use App\Helpers\Helper;
use App\Models\Config;


class PackageService
{
    protected Package $package;

    public function addPackage(array $request)
    {
        $validator = Validator::make($request, [
            //'total_days' => 'required',
            // 'starting_price' => 'nullable',
            //'featured_image_path' => 'image|mimes:jpeg,png,jpg,gif|max:2048', // Add appropriate image validation rules
            // Add other validation rules
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 400);
        }

        $originCityId = $request['origin'];
        $originCity = City::find($originCityId);
        // Create a package
        $package = Package::create([
            'user_id' => auth()->id(),
            'name' => $request['name'],
            'total_days' => $request['total_days'],
            'origin_state_id' => $originCity->state_id,
            'origin_city_id' => $originCityId,
            'destination_state_id' => $request['destination_state_id'],
            'destination_city_id' => $request['destination_city_id'],

            //'religion_id' => $request['religion_id'],
            'trip_id' => $request['trip_id'] ?? null,
            'type_of_tour_packages_id' => $request['type_of_tour_packages_id'] ?? null,
            'themes_id' => $request['themes_id'] ?? null,
            //'inclusions_in_package' => $request['inclusions_in_package']?? null,    ////Not needed
            'overview' => $request['overview'] ?? null,
            'inclusions_list' => $request['inclusions_list'] ?? null,
            'exclusions_list' => $request['exclusions_list'] ?? null,
            'terms_and_condition' => $request['terms_and_condition'] ?? null,
            'payment_policy' => $request['payment_policy'] ?? null,
            'cancellation_policy' => implode(',', $request['cancellation_policy']) ?? null,
            'keywords' => $request['keywords'] ?? null,
            'child_discount' => $request['child_discount'] ?? null,
            'single_occupancy_cost' => $request['single_occupancy_cost'] ?? null,
            'offseason_from_date' => $request['offseason_from_date'] ?? null,
            'offseason_to_date' => $request['offseason_to_date'] ?? null,
            'offseason_price' => $request['offseason_price'] ?? null,
            'onseason_from_date' => $request['onseason_from_date'] ?? null,
            'onseason_to_date' => $request['onseason_to_date'] ?? null,
            'onseason_price' => $request['onseason_price'] ?? null,
            'total_seat' => $request['total_seat'] ?? null,
            'bulk_no_of_pax' => $request['bulk_no_of_pax'] ?? 0,
            'pax_discount_percent' => $request['pax_discount_percent'] ?? 0,
            'starting_price' => $request['starting_price'] ?? null,
            'transportation_id' => $request['transportation_id'] ?? null,
            'hotel_star_id' => $request['hotel_star_id'] ?? null,
            'religion_id' => $request['religion_id'] ?? null,
            'tour_circuit' => $request['tour_circuit'] ?? null,

            'location' => $request['location'] ?? null,
            'status' => $request['status'] ?? null,
            'triple_sharing_discount' => $request['triple_sharing_discount'] ?? null,
        ]);

        if ($request['status'] == 1) {
            $originCity->increment('packages', 1);
        }

        // Handle featured image
        if (isset($request['featured_image_path'])) {
            $featuredImage = $request['featured_image_path'];

            // Check if the file is an instance of UploadedFile
            if ($featuredImage instanceof \Illuminate\Http\UploadedFile && $featuredImage->isValid()) {
                $filename = time() . '_' . $featuredImage->getClientOriginalName();
                $featuredImage->storeAs('public/uploads', $filename);
                $package->update(['featured_image_path' => 'uploads/' . $filename]);
            } else {
                // Log or handle the error
                return response()->json(['error' => 'Invalid or corrupted file for featured image'], 400);
            }
        } else {
            $package->update(['featured_image_path' => null]);
            // return response()->json(['error' => 'Featured image not provided'], 400);
        }

        // Handle gallery images
        if (isset($request['gallery_images'])) {
            foreach ($request['gallery_images'] as $image) {


                $filename = uniqid() . '.' . $image->getClientOriginalExtension();
                $path = 'gallery_images/' . $package->id . '/' . $filename;

                // Manually move the file to the storage path
                File::makeDirectory(storage_path('app/public/' . dirname($path)), 0755, true, true);
                $image->move(storage_path('app/public/' . dirname($path)), $filename);


                // Create a record in the database for the image
                PackageGalleryImage::create([
                    'package_id' => $package->id,
                    'path' => $path,
                ]);
            }
        }
        // Handle media links
        $packageMediaLinks = [];
        if (isset($request['media_links'])) {
            foreach ($request['media_links'] as $mediaLink) {
                $packageMediaLinks[] = [
                    'package_id' => $package->id,
                    'media_link' => $mediaLink,
                    'created_at' => now(),
                    'updated_at' => now(),
                ];
            }
        }

        // Insert media links into the package_media table
        PackageMedia::insert($packageMediaLinks);


        $addonsData = [];
        // Handle addons

        if (isset($request['addons'])) {
            $addonsData = $request['addons'];
            PackageAddon::addAddons($package->id, $addonsData);
        }
        // Handle package_seat_availability
        $packageSeatAvailabilityData = [];
        if (isset($request['seat_availability'])) {
            foreach ($request['seat_availability'] as $availability) {
                $packageSeatAvailabilityData[] = [
                    'package_id' => $package->id,
                    'date' => $availability['date'],
                    'seat' => $availability['seat'],
                    'cost' => $availability['cost'],
                ];
            }
        }
        PackageSeatAvailability::insert($packageSeatAvailabilityData);

        //itinerary
        $itineraryData = [];
        $packageFlightData = [];
        $packageTrainData = [];
        $packageLTData = [];
        $packageHotelData = [];
        $packageHotelGalleryImages = [];
        $packageSTData = [];
        $inclusionList = [];
        $exclusionList = [];

        if (isset($request['inclusion_list'])) {
            foreach ($request['inclusion_list'] as $inclusion) {
                $inclusionList[] = [
                    'package_id' => $package->id,
                    'name' => $inclusion['text'] ?? null,
                ];

            }
        }
        if (isset($request['exclusion_list'])) {
            foreach ($request['exclusion_list'] as $exclusion) {
                $exclusionList[] = [
                    'package_id' => $package->id,
                    'name' => $exclusion['text'] ?? null,
                ];

            }
        }

        if (isset($request['itinerary'])) {
            foreach ($request['itinerary'] as $itinerary) {
                // Insert into itineraries table and get the last inserted ID
                $lastInsertedId = DB::table('itineraries')->insertGetId([
                    'package_id' => $package->id,
                    'day' => $itinerary['day'],
                    'place_name' => $itinerary['place_name'] ?? null,
                    'itinerary_title' => $itinerary['itinerary_title'] ?? null,
                    'itinerary_description' => $itinerary['itinerary_description'] ?? null,
                    'meal' => $itinerary['meal'] ?? null,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);

                //Flight
                if (isset($itinerary['flights'])) {
                    $package->update(['is_flight' => 1]);
                    foreach ($itinerary['flights'] as $flight) {
                        $packageFlightData[] = [
                            'itinerary_id' => $lastInsertedId,
                            'depart_destination' => $flight['depart_destination'],
                            'arrive_destination' => $flight['arrive_destination'],
                            'depart_datetime' => $flight['depart_datetime'] ?? null,
                            'arrive_datetime' => $flight['arrive_datetime'] ?? null,
                            'created_at' => now(),
                            'updated_at' => now(),
                        ];
                    }
                }

                //Train
                if (isset($itinerary['trains'])) {
                    $package->update(['is_train' => 1]);
                    foreach ($itinerary['trains'] as $train) {
                        $packageTrainData[] = [
                            'itinerary_id' => $lastInsertedId,
                            'package_id' => $package->id,
                            'train_name' => $train['train_name'],
                            'train_number' => $train['train_number'],
                            'class' => $train['class'],
                            'from_station' => $train['from_station'],
                            'to_station' => $train['to_station'],
                            'depart_datetime' => $train['depart_datetime'] ?? null,
                            'arrive_datetime' => $train['arrive_datetime'] ?? null,
                        ];
                    }
                }
                //Local Transport
                if (isset($itinerary['local_transports'])) {
                    $package->update(['is_transport' => 1]);
                    foreach ($itinerary['local_transports'] as $transport) {
                        $packageLTData[] = [
                            'itinerary_id' => $lastInsertedId,
                            'car' => $transport['car'],
                            'model' => $transport['model'],
                            'capacity' => $transport['capacity'],
                            'AC' => $transport['AC'],
                            'created_at' => now(),
                            'updated_at' => now(),
                        ];
                    }
                }
                //Hotel
                if (isset($itinerary['hotel'])) {
                    $package->update(['is_hotel' => 1]);
                    foreach ($itinerary['hotel'] as $hotel) {
                        $lasthotelInsertedId = DB::table('package_hotel')->insertGetId([
                            //$packageHotelData[] = [
                            'itinerary_id' => $lastInsertedId,
                            'name' => $hotel['name'],
                            'rating' => $hotel['rating'],
                            'created_at' => now(),
                            'updated_at' => now(),
                            // ];
                        ]);


                        if (isset($hotel['gallery_images'])) {
                            foreach ($hotel['gallery_images'] as $image) {
                                $filename = uniqid() . '.' . $image->getClientOriginalExtension();
                                $path = 'hotel_gallery_images/' . $package->id . '/' . $filename;

                                // Manually move the file to the storage path
                                File::makeDirectory(storage_path('app/public/' . dirname($path)), 0755, true, true);
                                $image->move(storage_path('app/public/' . dirname($path)), $filename);

                                // Save information to the database
                                $packageHotelGalleryImages[] = [
                                    'hotel_id' => $lasthotelInsertedId,
                                    'path' => $path,
                                    'created_at' => now(),
                                    'updated_at' => now(),
                                ];
                            }
                        }


                    }
                    $packageHotelData[] = [
                        'itinerary_id' => $lastInsertedId,
                        'name' => $hotel['name'],
                        'rating' => $hotel['rating'],
                        'created_at' => now(),
                        'updated_at' => now(),
                    ];

                    //SIteseeing
                    if (isset($itinerary['siteseeing'])) {
                        $package->update(['is_sightseeing' => 1]);
                        foreach ($itinerary['siteseeing'] as $siteseeing) {
                            $packageSTData[] = [
                                'itinerary_id' => $lastInsertedId,
                                'morning' => $siteseeing['morning'] ?? null,
                                'afternoon' => $siteseeing['afternoon'] ?? null,
                                'evening' => $siteseeing['evening'] ?? null,
                                'night' => $siteseeing['night'] ?? null,
                                'created_at' => now(),
                                'updated_at' => now(),
                            ];
                        }
                    }


                }


                // Add the current $itinerary to $itineraryData
                $itineraryData[] = [
                    'package_id' => $package->id,
                    'day' => $itinerary['day'],
                    'place_name' => $itinerary['place_name'] ?? null,
                    'itinerary_title' => $itinerary['itinerary_title'] ?? null,
                    'itinerary_description' => $itinerary['itinerary_description'] ?? null,
                    'meal' => $itinerary['meal'] ?? null,
                    'created_at' => now(),
                    'updated_at' => now(),
                ];

                // Update is_meal if meal is not null
                if (isset($itinerary['meal']) && $itinerary['meal'] !== null) {
                    $package->update(['is_meal' => 1]);
                }


            }
        }

        PackageFlight::insert($packageFlightData);
        PackageTrain::insert($packageTrainData);
        PackageLocalTransport::insert($packageLTData);
        //PackageHotel::insert($packageHotelData);
        PackageHotelGalleryImage::insert($packageHotelGalleryImages);
        PackageSightseeing::insert($packageSTData);
        PackageInclusion::insert($inclusionList);
        PackageExclusion::insert($exclusionList);

        $stayPlanData = [];

        if (isset($request['stay_plan'])) {
            foreach ($request['stay_plan'] as $stayKey => $stay) {
                if (array_key_exists('hotel', $request['itinerary'][$stayKey])) {
                    $stayPlanData[] = [
                        'package_id' => $package->id,
                        'cities' => $stay['cities'] ?? null,
                        'total_nights' => $stay['total_nights'] ?? null,
                    ];
                }
            }
        }

        // Remove the last key-value pair as the last day of package does not contain any stay
        //array_pop($stayPlanData);

        DB::table('stay_plan')->insert($stayPlanData);

        // Load the gallery_images relationship
        $package->load('gallery_images');
        Helper::sendNotification(34, "A new package added.");
        return ['res' => true, 'msg' => 'Package added successfully', 'data' => [
            'package' => $package->toArray(),
            'stayplan' => $stayPlanData,
            'itinerary' => $itineraryData,
            'package_flight' => $packageFlightData,
            'package_Train' => $packageTrainData,
            'package_local_transport' => $packageLTData,
            'package_hotel' => $packageHotelData,
            'package_hotel_gallery' => $packageHotelGalleryImages,
            'package_siteseeing' => $packageSTData,
            'addons_data' => $addonsData,
            'package_media_links' => $packageMediaLinks,
            'packageSeatAvailabilityData' => $packageSeatAvailabilityData,
            'inclusionList' => $inclusionList,
            'exclusionList' => $exclusionList,
            'is_transport' => $package->is_transport,
            'is_flight' => $package->is_flight,
            'is_train' => $package->is_train,
            'is_hotel' => $package->is_hotel,
            'is_meal' => $package->is_meal,
            'is_sightseeing' => $package->is_sightseeing,
        ],];

    }

    public function editPackage(array $request)
    {
        $validator = Validator::make($request, [
            // Add validation rules
        ]);

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 400);
        }

        $package = Package::findOrFail($request['package_id']);


        $originCityId = $request['origin'];
        $originCity = City::find($originCityId);
        if ($request['origin'] != $package->origin_city_id) {
            City::where('id', $package->origin_city_id)
                ->decrement('packages', 1);

            if ($request['status'] == 1) {
                $originCity->increment('packages', 1);
            }
        }
        // Update package details
        $package->update([
            'name' => $request['name'],
            'total_days' => $request['total_days'],
            'origin_state_id' => $originCity->state_id,
            'origin_city_id' => $originCityId,
            'destination_state_id' => $request['destination_state_id'],
            'destination_city_id' => $request['destination_city_id'],

            //'religion_id' => $request['religion_id'],
            'trip_id' => $request['trip_id'] ?? null,
            'type_of_tour_packages_id' => $request['type_of_tour_packages_id'] ?? null,
            'themes_id' => $request['themes_id'] ?? null,
            'inclusions_in_package' => $request['inclusions_in_package'] ?? null,
            'overview' => $request['overview'] ?? null,
            'inclusions_list' => $request['inclusions_list'] ?? null,
            'exclusions_list' => $request['exclusions_list'] ?? null,
            'terms_and_condition' => $request['terms_and_condition'] ?? null,
            'payment_policy' => $request['payment_policy'] ?? null,
            'cancellation_policy' => implode(',', $request['cancellation_policy']) ?? null,
            'keywords' => $request['keywords'] ?? null,
            'child_discount' => $request['child_discount'] ?? null,
            'single_occupancy_cost' => $request['single_occupancy_cost'] ?? null,
            'offseason_from_date' => $request['offseason_from_date'] ?? null,
            'offseason_to_date' => $request['offseason_to_date'] ?? null,
            'offseason_price' => $request['offseason_price'] ?? null,
            'onseason_from_date' => $request['onseason_from_date'] ?? null,
            'onseason_to_date' => $request['onseason_to_date'] ?? null,
            'onseason_price' => $request['onseason_price'] ?? null,
            'total_seat' => $request['total_seat'] ?? null,
            'bulk_no_of_pax' => $request['bulk_no_of_pax'] ?? 0,
            'pax_discount_percent' => $request['pax_discount_percent'] ?? 0,
            'starting_price' => $request['starting_price'] ?? null,
            'transportation_id' => $request['transportation_id'] ?? null,
            'hotel_star_id' => $request['hotel_star_id'] ?? null,
            'religion_id' => $request['religion_id'] ?? null,
            'tour_circuit' => $request['tour_circuit'] ?? null,
            'location' => $request['location'] ?? null,
            'status' => $request['status'] ?? null,
            'triple_sharing_discount' => $request['triple_sharing_discount'] ?? null,
        ]);


        // Update Handle featured image
        if (isset($request['featured_image_path'])) {
            $featuredImage = $request['featured_image_path'];

            // Check if the file is an instance of UploadedFile
            if ($featuredImage instanceof \Illuminate\Http\UploadedFile && $featuredImage->isValid()) {
                $filename = time() . '_' . $featuredImage->getClientOriginalName();
                $featuredImage->storeAs('public/uploads', $filename);
                $package->update(['featured_image_path' => 'uploads/' . $filename]);
            } else {
                // Log or handle the error
                return response()->json(['error' => 'Invalid or corrupted file for featured image'], 400);
            }
        } else {
            $package->update(['featured_image_path' => null]);
            // return response()->json(['error' => 'Featured image not provided'], 400);
        }

        // Update Handle gallery images
        if (isset($request['gallery_images'])) {
            // Iterate through the new gallery images
            foreach ($request['gallery_images'] as $image) {
                $filename = uniqid() . '.' . $image->getClientOriginalExtension();
                $path = 'gallery_images/' . $package->id . '/' . $filename;

                // Store the new image
                $image->storeAs('public', $path);

                // Create a new record for the gallery image
                PackageGalleryImage::create([
                    'package_id' => $package->id,
                    'path' => $path,
                ]);
            }
        }

        //Update  Handle media links
        if (isset($request['media_links'])) {
            PackageMedia::where('package_id', $package->id)->delete();
            foreach ($request['media_links'] as $mediaLink) {

                PackageMedia::create([
                    'package_id' => $package->id,
                    'media_link' => $mediaLink,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }
        }

        // Update Handle addons
        if (isset($request['addons'])) {
            PackageAddon::where('package_id', $package->id)->delete();

            foreach ($request['addons'] as $addon) {

                PackageAddon::create([
                    'package_id' => $package->id,
                    'title' => $addon['title'],
                    'description' => $addon['description'],
                    'price' => $addon['price'],
                    'created_at' => now(),
                    'updated_at' => now(),

                ]);
            }
        }

        // Update Handle seat availability update
        if (isset($request['seat_availability'])) {
            $packageSeatAvailabilityData = [];
            foreach ($request['seat_availability'] as $availability) {
                PackageSeatAvailability::updateOrCreate(
                    [
                        'package_id' => $package->id,
                        'date' => $availability['date']
                    ],
                    [
                        'seat' => $availability['seat'],
                        'cost' => $availability['cost'],
                    ]
                );
//                // Check if the availability data already exists
//                $existingAvailability = PackageSeatAvailability::where('package_id', $package->id)
//                    ->where('date', $availability['date'])
//                    ->first();
//
//                if ($existingAvailability) {
//                    // Update existing availability data
//                    $existingAvailability->update([
//                        'seat' => $availability['seat'],
//                        'cost' => $availability['cost'],
//                    ]);
//                } else {
//                    // Create new availability data
//                    $packageSeatAvailabilityData[] = [
//                        'package_id' => $package->id,
//                        'date' => $availability['date'],
//                        'seat' => $availability['seat'],
//                        'cost' => $availability['cost'],
//                    ];
//                }
            }

            // Insert new availability data
            if (!empty($packageSeatAvailabilityData)) {
                PackageSeatAvailability::insert($packageSeatAvailabilityData);
            }
        }


        Itinerary::where('package_id', $package->id)->delete();
        // Handle itinerary update
        if (isset($request['itinerary'])) {
            foreach ($request['itinerary'] as $itinerary) {

                // Insert new itinerary
                $newItinerary = Itinerary::create([
                    'package_id' => $package->id,
                    'day' => $itinerary['day'],
                    'place_name' => $itinerary['place_name'] ?? null,
                    'itinerary_title' => $itinerary['itinerary_title'] ?? null,
                    'itinerary_description' => $itinerary['itinerary_description'] ?? null,
                    'meal' => $itinerary['meal'] ?? null,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);

                // Insert flights
                if (isset($itinerary['flights'])) {
                    $package->update(['is_flight' => 1]);
                    foreach ($itinerary['flights'] as $flight) {
                        PackageFlight::create([
                            'itinerary_id' => $newItinerary->id,
                            'depart_destination' => $flight['depart_destination'],
                            'arrive_destination' => $flight['arrive_destination'],
                            'depart_datetime' => $flight['depart_datetime'] ?? null,
                            'arrive_datetime' => $flight['arrive_datetime'] ?? null,
                            'created_at' => now(),
                            'updated_at' => now(),
                        ]);
                    }
                }

                // Insert trains
                if (isset($itinerary['trains'])) {
                    $package->update(['is_train' => 1]);
                    foreach ($itinerary['trains'] as $train) {
                        PackageTrain::create([
                            'itinerary_id' => $newItinerary->id,
                            'package_id' => $request['package_id'],
                            'train_name' => $train['train_name'],
                            'train_number' => $train['train_number'],
                            'class' => $train['class'],
                            'from_station' => $train['from_station'],
                            'to_station' => $train['to_station'],
                            'depart_datetime' => $train['depart_datetime'] ?? null,
                            'arrive_datetime' => $train['arrive_datetime'] ?? null,
                            'created_at' => now(),
                            'updated_at' => now(),
                        ]);
                    }
                }

                // Insert local transports
                if (isset($itinerary['local_transports'])) {
                    $package->update(['is_transport' => 1]);
                    foreach ($itinerary['local_transports'] as $transport) {
                        PackageLocalTransport::create([
                            'itinerary_id' => $newItinerary->id,
                            'car' => $transport['car'],
                            'model' => $transport['model'],
                            'capacity' => $transport['capacity'],
                            'AC' => $transport['AC'],
                            'created_at' => now(),
                            'updated_at' => now(),
                        ]);
                    }
                }
                $lasthotelInsertedId = null;
                $packageHotelGalleryImages = [];
                // Insert hotels
                if (isset($itinerary['hotel'])) {
                    $package->update(['is_hotel' => 1]);
                    foreach ($itinerary['hotel'] as $hotel) {
                        $lasthotelInsertedId = DB::table('package_hotel')->insertGetId([
                            'itinerary_id' => $newItinerary->id,
                            'name' => $hotel['name'],
                            'rating' => $hotel['rating'],
                            'created_at' => now(),
                            'updated_at' => now(),
                        ]);

                        if (isset($hotel['gallery_images'])) {
                            foreach ($hotel['gallery_images'] as $image) {
                                $filename = uniqid() . '.' . $image->getClientOriginalExtension();
                                $path = 'hotel_gallery_images/' . $package->id . '/' . $filename;

                                // Manually move the file to the storage path
                                File::makeDirectory(storage_path('app/public/' . dirname($path)), 0755, true, true);
                                $image->move(storage_path('app/public/' . dirname($path)), $filename);

                                // Save information to the database
                                $packageHotelGalleryImages[] = [
                                    'hotel_id' => $lasthotelInsertedId,
                                    'path' => $path,
                                    'created_at' => now(),
                                    'updated_at' => now(),
                                ];
                            }
                        }
                    }
                }
                PackageHotelGalleryImage::insert($packageHotelGalleryImages);
                // Insert sightseeing
                if (isset($itinerary['siteseeing'])) {
                    $package->update(['is_sightseeing' => 1]);
                    foreach ($itinerary['siteseeing'] as $sightseeing) {
                        PackageSightseeing::create([
                            'itinerary_id' => $newItinerary->id,
                            'morning' => $sightseeing['morning'] ?? null,
                            'afternoon' => $sightseeing['afternoon'] ?? null,
                            'evening' => $sightseeing['evening'] ?? null,
                            'night' => $sightseeing['night'] ?? null,
                            'created_at' => now(),
                            'updated_at' => now(),
                        ]);
                    }
                }

            }


        }


        // Handle inclusion, exclusion list
        PackageInclusion::where('package_id', $package->id)->delete();

        if (isset($request['inclusion_list'])) {
            foreach ($request['inclusion_list'] as $inclusion) {
                PackageInclusion::create([
                    'package_id' => $package->id,
                    'name' => $inclusion['text'],
                ]);
            }
        }

        PackageExclusion::where('package_id', $package->id)->delete();

        if (isset($request['exclusion_list'])) {
            foreach ($request['exclusion_list'] as $exclusion) {
                PackageExclusion::create([
                    'package_id' => $package->id,
                    'name' => $exclusion['text'],
                ]);
            }
        }

        // Update is_meal if meal is not null
        if (isset($itinerary['meal']) && $itinerary['meal'] !== null) {
            $package->update(['is_meal' => 1]);
        }

        // Delete existing stay_plan records for the current package
        DB::table('stay_plan')->where('package_id', $package->id)->delete();

        $stayPlanData = [];

        if (isset($request['stay_plan'])) {
            foreach ($request['stay_plan'] as $stayKey => $stay) {
                if (array_key_exists('hotel', $request['itinerary'][$stayKey])) {
                    $stayPlanData[] = [
                        'package_id' => $package->id,
                        'cities' => $stay['cities'] ?? null,
                        'total_nights' => $stay['total_nights'] ?? null,
                    ];
                }
            }
        }

        // Remove the last key-value pair as the last day of package does not contain any stay
        //array_pop($stayPlanData);

        // Insert new stay_plan records from the request
        DB::table('stay_plan')->insert($stayPlanData);


        return ['res' => true, 'msg' => 'Package edited successfully'];
    }


    public function getAllPackages(Request $request)
    {
        $query = Package::with([
            'religion',
            'themes',
            'transportation',
            'typeoftourpackages',
            'trip',
            'stayPlans'
         ])
            ->leftJoin('states', 'packages.destination_state_id', '=', 'states.id')
            ->leftJoin('cities as destination_city', 'packages.destination_city_id', '=', 'destination_city.id')
            ->leftJoin('cities as origin_city', 'packages.origin_city_id', '=', 'origin_city.id')
            ->leftJoin('type_of_tour_packages', 'packages.type_of_tour_packages_id', '=', 'type_of_tour_packages.id')
            ->leftJoin('users', 'packages.user_id', '=', 'users.id')
            ->leftJoin('vendor_details', 'packages.user_id', '=', 'vendor_details.user_id')
            ->select(
                'packages.*',
                'states.name as state_name',
                'destination_city.city as destination_city_name',
                'origin_city.city as origin_city_name',
                'type_of_tour_packages.name as type_name',
                'vendor_details.fullname as vendor_name',
            )
            ->addSelect(DB::raw('(SELECT path FROM package_gallery_images WHERE package_id = packages.id ORDER BY id ASC LIMIT 1) as first_gallery_image'))
            ->where('packages.status', 1);
        if ($request->has('featured') && $request->featured == 1) {
            // Fetch only featured packages
            $query->where('packages.featured', true);
        }

        // Add DISTINCT to ensure unique records
        $query->distinct();

        $packages = $query->get();


        return $packages;
    }

    public function getPackageDetails($id)
    {
        $packageDetails = Package::with(['religion', 'themes', 'transportation', 'typeoftourpackages', 'trip', 'cityStayPlans', 'inclusions', 'exclusions'])
            ->leftJoin('states', 'packages.destination_state_id', '=', 'states.id')
            ->leftJoin('cities', 'packages.destination_city_id', '=', 'cities.id')
            ->leftJoin('type_of_tour_packages', 'packages.type_of_tour_packages_id', '=', 'type_of_tour_packages.id')
            ->leftJoin('users', 'packages.user_id', '=', 'users.id')
            ->leftJoin('stay_plan', 'packages.id', '=', 'stay_plan.package_id')
            ->leftJoin('vendor_details', 'packages.user_id', '=', 'vendor_details.user_id')
            ->where('packages.id', $id)
            ->select(
                'packages.*',
                'states.name as state_name',
                'cities.city as cities_name',
                'type_of_tour_packages.name as type_name',
                //'users.name as vendor_name',
                'vendor_details.fullname as vendor_name',
            )
            ->groupBy('packages.id', 'vendor_details.fullname')
            ->first();


        // $stayPlan = DB::table('stay_plan')
        // ->join('cities', 'stay_plan.cities', '=', 'cities.id')
        // ->where('stay_plan.package_id', $id)
        // ->select('cities.city as city_name', DB::raw('COUNT(*) as total_days'), DB::raw('(COUNT(*) - 1) as total_nights'))
        // ->groupBy('cities.city')
        // ->get();
        //dd($packageDetails);
        $packageDetails->cancellation_policy = explode(',', $packageDetails->cancellation_policy);

        // fetch stay plan data according itineraries
        $packageDetails->stay_plan = $packageDetails->getItineraries($id);
        $terms = Config::where('name', 'terms_and_conditions')->first();
        $packageDetails->terms_and_condition = $terms->value;

        return $packageDetails;
    }

    public function getPackageCountsByState(Request $request)
    {
        try {

            $requestedDays = $request->input('total_days', 0);

            $packageCounts = Package::join('locations', 'packages.location', '=', 'locations.name')
                ->leftJoin('package_gallery_images as first_image', function ($join) {
                    $join->on('packages.id', '=', 'first_image.package_id')
                        ->whereRaw('first_image.id = (SELECT id FROM package_gallery_images WHERE package_id = packages.id ORDER BY id ASC LIMIT 1)');
                })
                ->select(
                    'locations.id as location_id',
                    'locations.name as location_name',
                    DB::raw('COUNT(packages.id) as package_count'),
                    DB::raw('ROUND(MIN(packages.starting_price)) as min_starting_price'),
                    DB::raw('MIN(first_image.path) as last_featured_image_path')
                )
                ->where('packages.status', 1);


            if ($requestedDays > 0) {
                $packageCounts->whereBetween('packages.total_days', [$requestedDays - 2, $requestedDays]);
            }

            $packageCounts = $packageCounts
                ->groupBy('location_id', 'location_name')
                ->get();

            return $packageCounts;
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => $e->getMessage()], 500);
        }
    }

    public function ____getPopularDestination(Request $request)
    {
        try {

            $lastTwoPackages = Package::orderBy('id', 'desc')
                ->limit(6)
                ->get();

            $lastPackageImages = collect();

            foreach ($lastTwoPackages as $package) {
                $lastGalleryImage = PackageGalleryImage::where('package_id', $package->id)
                    ->orderBy('id', 'desc')
                    ->first();

                if ($lastGalleryImage) {
                    $lastPackageImages[$package->destination_state_id] = $lastGalleryImage->path;
                }
            }


            $cityIds = $lastTwoPackages->pluck('destination_city_id');


            $cityData = DB::table('cities')
                ->whereIn('id', $cityIds)
                ->select('id', 'city')
                ->get();


            $stateData = DB::table('states')
                ->whereIn('id', $lastTwoPackages->pluck('destination_state_id'))
                ->select('id', 'name')
                ->get();


            $result = $stateData->map(function ($state) use ($lastPackageImages, $cityData, $lastTwoPackages) {

                $cityId = $lastTwoPackages
                    ->where('destination_state_id', $state->id)
                    ->pluck('destination_city_id')
                    ->first();


                $state->city = $cityData->where('id', $cityId)->pluck('city')->first() ?? null;


                $state->last_package_featured_image_path = $lastPackageImages[$state->id] ?? null;

                return $state;
            });

            return $result;
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => $e->getMessage()], 500);
        }
    }

    public function getPopularDestination(Request $request)
    {
        try {

            $lastPackages = Package::select('location', \DB::raw('MAX(id) as max_id'))
                ->groupBy('location')
                ->take(6)
                ->get();


            $lastPackageImages = PackageGalleryImage::whereIn('package_id', $lastPackages->pluck('max_id'))
                ->get()
                ->keyBy('package_id')
                ->map->path;


            $result = $lastPackages->map(function ($package) use ($lastPackageImages) {
                return [
                    'location' => $package->location,
                    'last_package_featured_image_path' => $lastPackageImages[$package->max_id] ?? null
                ];
            });
            // dd($result);
            return $result;
        } catch (\Exception $e) {
            return response()->json(['res' => false, 'msg' => $e->getMessage()], 500);
        }
    }

    public function getDestinationsByTheme()
    {
        try {
            $themesData = Themes::leftJoin('packages', 'themes.id', '=', 'packages.themes_id')
                ->select('themes.id as theme_id', 'themes.name', 'themes.image', DB::raw('COUNT(DISTINCT packages.destination_state_id) as destination_state_count'))
                ->groupBy('themes.id', 'themes.name', 'themes.image')
                ->orderBy('themes.id', 'asc')
                ->take(4)
                ->get();

            return $themesData;
        } catch (\Exception $e) {

            throw $e;
        }
    }

    public function filterPackages($filters)
    {
        $query = Package::with([
            'religion',
            'themes',
            'transportation',
            'typeoftourpackages',
            'trip',
            'stayPlans'
        ])
        ->leftjoin('states', 'packages.destination_state_id', '=', 'states.id')
        ->leftjoin('cities as destination_city', 'packages.destination_city_id', '=', 'destination_city.id')
        ->leftjoin('cities as origin_city', 'packages.origin_city_id', '=', 'origin_city.id')
        ->leftjoin('type_of_tour_packages', 'packages.type_of_tour_packages_id', '=', 'type_of_tour_packages.id')
        ->leftjoin('users', 'packages.user_id', '=', 'users.id')
        ->leftJoin('vendor_details', 'packages.user_id', '=', 'vendor_details.user_id')
        ->select(
            'packages.*',
            'states.name as state_name',
            'destination_city.city as destination_city_name',
            'origin_city.city as origin_city_name',
            'type_of_tour_packages.name as type_name',
            'vendor_details.fullname as vendor_name',
        )
        ->addSelect(DB::raw('(SELECT path FROM package_gallery_images WHERE package_id = packages.id ORDER BY id ASC LIMIT 1) as featured_image_path'))
        ->addSelect(DB::raw('(SELECT MAX(rating) as rating FROM package_hotel WHERE package_id = packages.id LIMIT 1) as rating'))
        ->where('packages.status', 1);


        if (isset($filters['from_city_id'])) {
            $originCityId = $filters['from_city_id'];
            $originCity = City::find($originCityId);
            $query->where(function ($query) use ($originCityId, $originCity) {
                $query->where('origin_city_id', $originCityId)
                    ->orWhere('origin_city_id', function ($query) use ($originCityId, $originCity) {
                        $query->select('id')
                            ->from('cities')
                            ->where('state_id', $originCity->state_id)
                            ->where('id', '!=', $originCityId)
                            ->where('packages', '>', 0)
                            ->orderByRaw('SQRT(POW((lat - (SELECT lat FROM cities WHERE id = ?)), 2) + POW((lng - (SELECT lng FROM cities WHERE id = ?)), 2))', [$originCityId, $originCityId])
                            ->limit(1);
                    });
            });
        }

        if (isset($filters['filter_location']) && $filters['filter_location'] !== '') {
            $locationId = $filters['filter_location'];
            $locationName = Location::where('id', $locationId)->pluck('name');
            $query->where('location', $locationName);
        }

        if (isset($filters['filter_keywords'])) {

            $keywords = is_array($filters['filter_keywords']) ? $filters['filter_keywords'] : [$filters['filter_keywords']];
            $query->where(function ($query) use ($keywords) {
                $first = true;
                foreach ($keywords as $keyword) {
                    $locationKeywordName = LocationKeyword::where('id', $keyword)->pluck('name');
                    if ($first) {
                        $query->where(function ($query) use ($locationKeywordName) {
                            $query->orWhereRaw('FIND_IN_SET(?, packages.keywords) > 0', [$locationKeywordName]);
                        });
                        $first = false;
                    } else {
                        $query->orWhere(function ($query) use ($locationKeywordName) {
                            $query->orWhereRaw('FIND_IN_SET(?, packages.keywords) > 0', [$locationKeywordName]);
                        });
                    }
                }
            });
        }

        if (isset($filters['transportations'])) {
            $transportations = $filters['transportations'];

            $query->where(function ($query) use ($transportations) {
                foreach ($transportations as $transportation) {
                    if ($transportation === 'flight') {
                        $query->orWhere('is_flight', 1);
                    } elseif ($transportation === 'train') {
                        $query->orWhere('is_train', 1);
                    }
                }
            });
        }


        if (isset($filters['hotel_stars'])) {
            $hotelStars = $filters['hotel_stars'];

            if(in_array('5', $hotelStars)) {
                $query->orHavingRaw('rating = ?', [5]);
            }
            if(in_array('4', $hotelStars)) {
                $query->orHavingRaw('rating = ?', [4]);
            }
            if(in_array('3', $hotelStars)) {
                $query->orHavingRaw('rating <= ?', [3]);
            }
        }

        if (isset($filters['religion_id'])) {
            $religionId = is_array($filters['religion_id']) ? $filters['religion_id'] : [$filters['religion_id']];
            $query->whereIn('religion_id', $religionId);
        }

        if (isset($filters['trip_id'])) {
            $tripId = is_array($filters['trip_id']) ? $filters['trip_id'] : [$filters['trip_id']];
            $query->whereIn('trip_id', $tripId);
        }

        if (isset($filters['type_of_tour_packages_id'])) {
            $type_of_tour_packages_id = is_array($filters['type_of_tour_packages_id']) ? $filters['type_of_tour_packages_id'] : [$filters['type_of_tour_packages_id']];
            $query->whereIn('type_of_tour_packages_id', $type_of_tour_packages_id);
        }

        if (isset($filters['themes_id'])) {
            $themes_id = is_array($filters['themes_id']) ? $filters['themes_id'] : [$filters['themes_id']];
            $query->whereIn('themes_id', $themes_id);
        }

        if (isset($filters['location'])) {
            $location = is_array($filters['location']) ? $filters['location'] : [$filters['location']];
            $query->whereIn('location', $location);
        }


        if (isset($filters['keyword'])) {
            $keywords = explode(',', $filters['keyword']);


            foreach ($keywords as $keyword) {
                $query->orWhere('keywords', 'LIKE', '%' . trim($keyword) . '%');
            }
        }


        if (isset($filters['total_days'])) {
            $totalDaysRange = explode('-', $filters['total_days']);
            $query->whereBetween('total_days', $totalDaysRange);
        }

        if (isset($filters['duration'])) {
            $duration = is_array($filters['duration']) ? $filters['duration'] : [$filters['duration']];
            $query->whereIn('total_days', $duration);
        }

        if (isset($filters['starting_price'])) {
            $totalstarting_priceRange = explode('-', $filters['starting_price']);
            $query->whereBetween('starting_price', $totalstarting_priceRange);
        }
        if (isset($filters['is_train'])) {
            $isTrain = $filters['is_train'];
            $query->where('is_train', $isTrain);
        }
        if (isset($filters['is_flight'])) {
            $isFlight = $filters['is_flight'];
            $query->where('is_flight', $isFlight);
        }

//        if (isset($filters['slot_price']) && is_array($filters['slot_price'])) {
//            $first = true;
//            foreach ($filters['slot_price'] as $slotRange) {
//                $range = explode('-', $slotRange);
//                if ($first) {
//                    $query->whereBetween('starting_price', $range);
//                    $first = false;
//                } else {
//                    $query->orWhere(function ($query) use ($range) {
//                        $query->whereBetween('starting_prices', $range);
//                    });
//                }
//            }
//        }

        if (isset($filters['slot_price']) && is_array($filters['slot_price'])) {
            $query->where(function ($query) use ($filters) {
                $first = true;
                foreach ($filters['slot_price'] as $slotRange) {
                    $range = explode('-', $slotRange);
                    if ($first) {
                        $query->where(function ($query) use ($range) {
                            $query->whereBetween('starting_price', $range);
                        });
                        $first = false;
                    } else {
                        $query->orWhere(function ($query) use ($range) {
                            $query->whereBetween('starting_price', $range);
                        });
                    }
                }
            });
        }

        $packages = $query->get();

        return $packages;
    }


    public function getStateList(Request $request)
    {
        $state = State::get();
        return $state;
    }

    public function getCityList(Request $request)
    {
        $query = City::query();


        if ($request->has('state')) {
            $states = $request->input('state');
            $query->whereIn('state_id', $states);
        }


        $cities = $query->get();

        return $cities;
    }

    public function getTransportationList(Request $request)
    {
        $transportation = Transportation::get();
        return $transportation;
    }

    public function gettripList(Request $request)
    {
        $trip = Trip::get();
        return $trip;
    }

    public function gettypeOfTourPackagesList(Request $request)
    {
        $typeOfTourPackages = TypeOfTourPackages::get();
        return $typeOfTourPackages;
    }

    public function gettypeOfVendorList(Request $request)
    {
        $typeOfVendor = VendorType::get();
        return $typeOfVendor;
    }

    public function getthemesList(Request $request)
    {
        $themes = Themes::get();
        return $themes;
    }

    public function getreligionList(Request $request)
    {
        $religion = Religion::get();
        return $religion;
    }

    public function gettotalday(Request $request)
    {
        $minDay = Package::min('total_days');
        $maxDay = Package::max('total_days');

        return [
            'min_day' => $minDay,
            'max_day' => $maxDay,
        ];
    }

    public function getstartingpriceRange(Request $request)
    {
        $minPrice = round(Package::min('starting_price'));
        $maxPrice = round(Package::max('starting_price'));
        $numSlots = 4;

        $slotRanges = $this->generatePriceSlots($minPrice, $maxPrice, $numSlots);
        $slotCounts = $this->getPackageCountsInSlots($slotRanges);

        return [
            'min_price' => $minPrice,
            'max_price' => $maxPrice,
            // 'slot_ranges' => $slotRanges,
            'slot_counts' => $slotCounts,
        ];
    }

    private function generatePriceSlots($minPrice, $maxPrice, $numSlots)
    {
        $slotRanges = [];
        $slotSize = ($maxPrice - $minPrice) / $numSlots;

        for ($i = 0; $i < $numSlots; $i++) {
            $start = $minPrice + ($i * $slotSize);
            $end = $minPrice + (($i + 1) * $slotSize);

            $slotRanges[] = [
                'start' => round($start),
                'end' => round($end),
            ];
        }

        return $slotRanges;
    }

    private function getPackageCountsInSlots($slotRanges)
    {
        $slotCounts = [];

        foreach ($slotRanges as $slot) {
            $count = Package::whereBetween('starting_price', [$slot['start'], $slot['end']])->count();
            $slotCounts[] = [
                'start' => $slot['start'],
                'end' => $slot['end'],
                'count' => $count,
            ];
        }

        return $slotCounts;
    }

    public function getComparePackagelist(array $packageIds)
    {
        $compareList = [];

        foreach ($packageIds as $packageId) {
            $package = Package::with([
                'religion',
                'themes',
                'transportation',
                'typeoftourpackages',
                'trip',
                'stayPlans'
            ])
                ->leftjoin('states', 'packages.destination_state_id', '=', 'states.id')
                ->leftjoin('cities', 'packages.destination_city_id', '=', 'cities.id')
                //->leftJoin('package_gallery_images', 'packages.id', '=', 'package_gallery_images.package_id')
                ->leftjoin('type_of_tour_packages', 'packages.type_of_tour_packages_id', '=', 'type_of_tour_packages.id')
                ->leftjoin('users', 'packages.user_id', '=', 'users.id')
                ->leftJoin('vendor_details', 'packages.user_id', '=', 'vendor_details.user_id')
                ->leftJoin('package_gallery_images', function ($join) {
                    $join->on('packages.id', '=', 'package_gallery_images.package_id')
                        ->whereRaw('package_gallery_images.id = (select min(id) from package_gallery_images where package_id = packages.id)');
                })
                ->select(
                    'packages.*',
                    'states.name as state_name',
                    'cities.city as cities_name',
                    //  'package_gallery_images.path as featured_image_path',
                    'type_of_tour_packages.name as type_name',
                    // 'users.name as vendor_name',
                    'vendor_details.fullname as vendor_name',
                    'package_gallery_images.path as featured_image_path'
                )
                ->where('packages.id', $packageId)
                ->where('packages.status', 1)
                ->first();

            if ($package) {
                $totalDays = $package->total_days;
                $totalNights = $package->fetchStayPlans()->sum('total_nights');
                $totalDaysAndNights = "$totalDays days and $totalNights night" . ($totalNights > 1 ? 's' : '');

                $galleryImages = $package->gallery_images ?? [];


                $inclusionIds = explode(',', $package->inclusions_in_package);


                $inclusions = DB::table('package_inclusions')
                    ->whereIn('id', $inclusionIds)
                    ->select(['name'])
                    ->get();

                $compareList[] = [
                    'package_id' => $package->id,
                    'vendor_name' => $package->vendor_name,
                    'featured' => $package->featured,
                    'package_name' => $package->name,
                    'total_days' => $totalDaysAndNights,
                    'total_days_count' => (int)$totalDays,
                    'total_nights_count' => (int)$totalNights,
                    'starting_price' => round($package->starting_price),
                    'state_name' => $package->state_name,
                    'cities_name' => $package->cities_name,
                    'keywords' => $package->keywords,
                    'transportation_name' => $package->transportation->name ?? null,
                    'hotel_star' => $package->hotel_star_id,
                    'religion' => $package->religion->name ?? null,
                    'trip' => $package->trip->name,
                    'type_of_tour_packages' => $package->type_name,
                    'themes' => $package->themes->name,
                    'featured_image_path' => $package->featured_image_path,
                    'galleryImages' => $galleryImages,
                    'inclusions_in_package' => $inclusions,
                    'overview' => $package->overview,
                    'inclusions_list' => $package->inclusions_list,
                    'exclusions_list' => $package->exclusions_list,
                    'terms_and_condition' => $package->terms_and_condition,
                    'stay_plan' => $package->fetchStayPlans(),
                    'created_at' => date($package->created_at),
                    'is_transport' => $package->is_transport,
                    'is_flight' => $package->is_flight,
                    'is_train' => $package->is_train,
                    'is_hotel' => $package->is_hotel,
                    'is_meal' => $package->is_meal,
                    'is_sightseeing' => $package->is_sightseeing,
                ];
            }
        }

        return $compareList;
    }

    public function vendorPackageList(Request $request)
    {
        $query = Package::with([
            'religion',
            'themes',
            'transportation',
            'typeoftourpackages',
            'trip',
            'stayPlans'
        ])
            ->leftjoin('states', 'packages.destination_state_id', '=', 'states.id')
            ->leftjoin('cities', 'packages.destination_city_id', '=', 'cities.id')
            ->leftjoin('type_of_tour_packages', 'packages.type_of_tour_packages_id', '=', 'type_of_tour_packages.id')
            ->leftjoin('users', 'packages.user_id', '=', 'users.id')
            ->leftJoin('vendor_details', 'packages.user_id', '=', 'vendor_details.user_id')
            ->select(
                'packages.*',
                'states.name as state_name',
                'cities.city as cities_name',
                'type_of_tour_packages.name as type_name',
                //'users.name as vendor_name'
                'vendor_details.fullname as vendor_name',
            );

        if ($request->has('featured') && $request->featured == 1) {

            $query->where('packages.featured', true);
        }

        if ($request->has('status')) {

            $query->where('packages.status', $request->status);
        }
        if ($request->has('search')) {

            $query->where('packages.name', 'like', '%' . $request->search . '%');
        }
        if (auth()->check()) {

            $query->where('packages.user_id', auth()->id());
        }
        $query->where('packages.status', '!=', 3);
        $query->orderBy('packages.updated_at', 'desc');
        $packages = $query->get();
        // View the generated SQL query
        // $sql = $query->toSql();
        //  dd($packages); // Output the SQL query to the screen

        return $packages;
    }

    public function updatePackageStatus(array $packageIds, int $status)
    {
        try {

            DB::table('packages')
                ->whereIn('id', $packageIds)
                ->update(['status' => $status]);

            return true;
        } catch (\Exception $e) {

            throw new \Exception('Failed to update package status: ' . $e->getMessage());
        }
    }


    public function getAddonsByPackageId($packageId)
    {
        return PackageAddon::where('package_id', $packageId)->get();
    }

    public function getseatAvailability($packageId)
    {
        return PackageSeatAvailability::where('package_id', $packageId)->get();
    }

    public function getRelatedPackages($packageId)
    {
        $mainPackage = Package::findOrFail($packageId);
        $keywords = $mainPackage->keywords;

        if ($keywords === null) {
            throw new \Exception('Keywords not found for the main package');
        }

        $keywordArray = explode(',', $keywords);

        $relatedPackages = Package::with([
            'religion',
            'themes',
            'transportation',
            'typeoftourpackages',
            'trip',
            'stayPlans'
        ])
            ->leftjoin('states', 'packages.destination_state_id', '=', 'states.id')
            ->leftjoin('cities', 'packages.destination_city_id', '=', 'cities.id')
            ->leftjoin('type_of_tour_packages', 'packages.type_of_tour_packages_id', '=', 'type_of_tour_packages.id')
            ->leftjoin('users', 'packages.user_id', '=', 'users.id')
            ->leftJoin('vendor_details', 'packages.user_id', '=', 'vendor_details.user_id')
            ->select(
                'packages.*',
                'states.name as state_name',
                'cities.city as cities_name',
                'type_of_tour_packages.name as type_name',
                'vendor_details.fullname as vendor_name',
            )
            ->addSelect(DB::raw('(SELECT path FROM package_gallery_images WHERE package_id = packages.id ORDER BY id ASC LIMIT 1) as first_gallery_image'))
            ->where('packages.status', 1)
            ->where(function ($query) use ($keywordArray) {
                foreach ($keywordArray as $keyword) {
                    $query->orWhere('keywords', 'like', '%' . $keyword . '%');
                }
            })
            ->where('packages.id', '!=', $packageId)
            ->distinct()
            ->get();

        return $relatedPackages;
    }
}
