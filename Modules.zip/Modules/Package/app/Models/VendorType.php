<?php

namespace Modules\Package\app\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VendorType extends Model
{
    use HasFactory;

    protected $table = "vendor_type";

    protected $fillable=[
        'vendor_type',
       
    ];
    /**
     * Define the reverse relationship with the Package model.
     */
    public function packages()
    {
        return $this->hasMany(Package::class);
    }
}
