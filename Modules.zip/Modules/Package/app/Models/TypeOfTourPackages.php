<?php

namespace Modules\Package\app\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TypeOfTourPackages extends Model
{
    use HasFactory;

    protected $table = "type_of_tour_packages";

    protected $fillable=[
        'name',
       
    ];
    /**
     * Define the reverse relationship with the Package model.
     */
    public function packages()
    {
        return $this->hasMany(Package::class);
    }
}
