<?php

namespace Modules\Package\app\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Package\Database\factories\PackageFactory;

class Package extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'id',
        'user_id',
        'name',
        'total_days',
        'starting_price',
        'origin_state_id',
        'origin_city_id',
        'destination_state_id',
        'destination_city_id',
        'keywords',
        'transportation_id',
        'hotel_star_id',
        'religion_id',
        'trip_id',
        'type_of_tour_packages_id',
        'themes_id',
        'featured_image_path',
        'inclusions_in_package',
        'overview',
        'payment_policy',
        'cancellation_policy',
        'terms_and_condition',
        'featured',
        'tour_circuit',
        'location',
        'child_discount',
        'single_occupancy_cost',
        'offseason_from_date',
        'offseason_to_date',
        'offseason_price',
        'onseason_from_date',
        'onseason_to_date',
        'onseason_price',
        'total_seat',
        'bulk_no_of_pax',
        'pax_discount_percent',
        'status',
        'is_transport',
        'is_flight',
        'is_train',
        'is_hotel',
        'is_meal',
        'is_sightseeing',
        'triple_sharing_discount',
        'verified',

    ];

    protected $casts = [
        'featured_image_path' => 'string',
    ];
    /**
     * Define the relationship with the Religion model.
     */
    public function religion()
    {
        return $this->belongsTo(Religion::class);
    }

    /**
     * Define the relationship with the Themes model.
     */
    public function themes()
    {
        return $this->belongsTo(Themes::class);
    }

     /**
     * Define the relationship with the Transportation model.
     */
    public function transportation()
    {
        return $this->belongsTo(Transportation::class);
    }
      /**
     * Define the relationship with the TypeOfTourPackages model.
     */
    public function typeoftourpackages()
    {
        return $this->belongsTo(TypeOfTourPackages::class);
    }

    /**
     * Define the relationship with the Trip model.
     */
    public function trip()
    {
        return $this->belongsTo(Trip::class);
    }
    /**
     * Define the relationship with the galleryImages model.
     */
  
  
     public function getGalleryImagesAttribute()
     {
         //return $this->gallery_images()->pluck('path')->toArray();
         return $this->gallery_images()->select('id', 'path')->get()->toArray();
     }
     
     public function gallery_images()
     {
         return $this->hasMany(PackageGalleryImage::class, 'package_id', 'id');
     }

     public function stayPlans()
    {
        return $this->hasMany(StayPlan::class, 'package_id');
    }

//    public function fetchStayPlans()
//    {
//        return $this->stayPlans()->with('city:id,city')->get()->map(function ($stayPlan) {
//            return [
//                'city_name' => $stayPlan->city->city,
//                'total_nights' => $stayPlan->count(),
//            ];
//        });
//    }

    public function fetchStayPlans()
    {
        return $this->stayPlans()->with('city:id,city')->get()->groupBy('city.city')->map(function ($stayPlans, $cityName) {
            return (object) [
                'city_name' => $cityName,
                'total_nights' => $stayPlans->count(),
            ];
        })->values();
    }

    public function trains()
    {
        return $this->hasMany(PackageTrain::class, 'package_id');
    }

    // Add a new relationship to fetch city name
    public function stayPlanCities()
    {
        return $this->hasMany(StayPlan::class, 'package_id')
            ->join('cities', 'stay_plan.cities', '=', 'cities.id')
            ->select('stay_plan.*', 'cities.city as city_name');
    }

    public function cityStayPlans()
    {
        return $this->hasMany(StayPlan::class, 'package_id')
            ->join('cities', 'stay_plan.cities', '=', 'cities.id')
            ->select(
                'cities.city as city_name',
                DB::raw('COUNT(stay_plan.id) as total_nights')
            )
            ->groupBy('stay_plan.cities');
    }

    public function itineraries()
    {
        return $this->hasMany(Itinerary::class);
    }

    public function getItineraries($id)
    {
        return Itinerary::join('cities', 'itineraries.place_name', '=', 'cities.id')
            ->join('package_hotel', 'itineraries.id', '=', 'package_hotel.itinerary_id')
            ->where('itineraries.package_id', $id)
            ->select(
                'cities.city as city_name',
                'package_hotel.name as hotel_name',
                DB::raw('COUNT(*) as total_nights'),
                DB::raw('MIN(itineraries.id) as itinerary_id')
            )
            ->groupBy('cities.city', 'package_hotel.name')
            ->orderBy('itinerary_id')
            ->get();
    }

    public function mediaLinksAttribute()
    {
        return $this->mediaLinks()->pluck('media_link')->toArray();
    }
    
    public function mediaLinks()
    {
        return $this->hasMany(PackageMedia::class, 'package_id', 'id');
    }
    public function addons()
    {
        return $this->hasMany(PackageAddon::class, 'package_id', 'id');
    }
    public function seatAvailability()
    {
        return $this->hasMany(PackageSeatAvailability::class, 'package_id', 'id');
    }

    public function itinerary()
    {
        return $this->hasMany(Itinerary::class, 'package_id', 'id');
    }
    public function inclusions()
    {
        return $this->hasMany(PackageInclusion::class, 'package_id', 'id');
    }
    public function exclusions()
    {
        return $this->hasMany(PackageExclusion::class, 'package_id', 'id');
    }




    protected static function newFactory(): PackageFactory
    {
        //return PackageFactory::new();
    }
} 
