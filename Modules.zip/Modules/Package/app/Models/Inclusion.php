<?php

namespace Modules\Package\app\Models;

use Illuminate\Database\Eloquent\Model;

class Inclusion extends Model
{
    protected $fillable = ['name'];
}
