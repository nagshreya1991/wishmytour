<?php

use Illuminate\Support\Facades\Route;
use App\Http\Middleware\LogAdminActivity;
use Modules\Admin\app\Http\Controllers\AdminController;
use Modules\Admin\app\Http\Controllers\InclusionController;
use Modules\Admin\app\Http\Controllers\ExclusionController;
use Modules\Admin\app\Http\Controllers\LocationController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::middleware(['auth', LogAdminActivity::class])
    ->prefix('admin')
    ->name('admin.')
    ->group(function () {
        Route::get('/dashboard', [AdminController::class, 'dashboard'])->name('dashboard');
        Route::get('/customers', [AdminController::class, 'customers'])->name('customers');
        Route::get('/customers/{id}/edit', [AdminController::class, 'customerEdit'])->name('customers.edit');
        Route::put('/customers/{id}', [AdminController::class, 'customerUpdate'])->name('customers.update');
        Route::get('/vendors', [AdminController::class, 'vendors'])->name('vendors');
        Route::put('/vendors/{id}', [AdminController::class, 'vendorUpdate'])->name('vendors.update');
        Route::get('/vendors/{id}/edit', [AdminController::class, 'vendorEdit'])->name('vendors.edit');

        Route::get('/packages', [AdminController::class, 'packages'])->name('packages');
        Route::put('/packages/{id}', [AdminController::class, 'packagesUpdate'])->name('packages.update');
        Route::get('/packages/{id}/view', [AdminController::class, 'packagesView'])->name('packages.view');

        Route::resource('/inclusions', InclusionController::class);
        Route::resource('/exclusions', ExclusionController::class);
        Route::resource('/locations', LocationController::class);

        Route::get('/notifications', [AdminController::class, 'notificationList'])->name('notifications');
        Route::delete('/notifications/{id}', [AdminController::class, 'deleteNotification'])->name('notifications.delete');
       // Route::delete('/notifications/bulk-delete', [AdminController::class, 'bulkDeleteNotifications'])->name('admin.notifications.bulkDelete');
        Route::post('/notifications/mark-all-as-read', [AdminController::class, 'markAllNotificationsAsRead'])->name('notifications.markAllAsRead');
        Route::post('/notifications/clear-all', [AdminController::class, 'clearAllNotifications'])->name('notifications.clearAll');
        Route::post('/notifications/remove-all', [AdminController::class, 'removeAllNotifications'])->name('notifications.removeAll');


        Route::get('/booking', [AdminController::class, 'booking'])->name('booking');
        Route::get('/booking/{id}/view', [AdminController::class, 'bookingView'])->name('booking.view');
        

    });

// Admin Login routes
Route::get('/admin', [AdminController::class, 'index'])->name('admin.login');
Route::post('/admin', [AdminController::class, 'login']);
Route::post('/admin/logout', [AdminController::class, 'logout'])->name('admin.logout');

Route::get('/render-header', [YourController::class, 'renderHeader']);
