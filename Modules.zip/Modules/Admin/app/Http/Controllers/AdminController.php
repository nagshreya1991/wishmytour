<?php

namespace Modules\Admin\app\Http\Controllers;

use App\Http\Controllers\Controller;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Modules\User\app\Models\User;
use Carbon\Carbon;
use DB;
use Modules\Package\app\Models\Package;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Modules\User\app\Models\CustomerDetail;
use Modules\User\app\Models\VendorDetails;
use App\Helpers\NotificationHelper;
use Modules\Package\app\Models\City;
use Modules\Package\app\Models\PackageHotelGalleryImage;
use Modules\Admin\app\Http\Services\AdminService;
use Modules\Package\app\Models\Themes;
use App\Models\Notification;
use Modules\Booking\app\Models\Booking;
use Modules\Booking\app\Models\BookingCustomerDetails;
use Modules\Booking\app\Models\BookingRoom;
use Modules\Booking\app\Models\BookingDate;
use Modules\Booking\app\Models\BookingPassenger;


class AdminController extends Controller
{
    protected $adminService;

    public function __construct(AdminService $adminService)
    {
        $this->adminService = $adminService;
    }


    public function index()
    {
        return view('backend.index');
        
    }

    public function dashboard()
    {
        $customerCount = User::where('user_type', 2)->count();
        $vendorCount = User::where('user_type', 3)->count();
        $packageCount = Package::where('status', 1)->count();
        $bookingCount = Booking::where('booking_status', 1)->count();
        return view('backend.dashboard', compact('customerCount', 'vendorCount', 'packageCount', 'bookingCount'));
    }

    public function login(Request $request)
    {

        $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        $user = User::where('email', $request->email)->first();
        if (!$user || !Hash::check($request->password, $user->password)) {
            return back()->withErrors(['email' => 'Invalid credentials'])->withInput();
        }

        if ($user->user_type !== 1) {
            return back()->withErrors(['email' => 'Unauthorized'])->withInput();
        }
        if (Auth::attempt(['email' => $request->email, 'password' => $request->password])) {
            return redirect()->intended('/admin/dashboard');
        }
        return back()->withErrors(['email' => 'Invalid credentials'])->withInput();
    }

    // Logout
    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('admin.login');
    }

    //User list
    public function customers()
    {

        $users = User::where('user_type', 2)->with('customerDetail')->get();

        return view('backend.users.index', compact('users'));
    }

    // Function to show the edit form
    public function customerEdit($id)
    {
        $user = User::findOrFail($id);
        return view('backend.users.edit', compact('user'));
    }

    public function customerUpdate(Request $request, $id)
    {

        // $validator = Validator::make($request->all(), [
        //        'email' => 'required|email|max:255',
        //     'mobile' => 'required|string|max:15',
        //     'status' => 'required|in:active,inactive',

        //     // Validation rules for CustomerDetail model fields
        //     'first_name' => 'required|string|max:255',
        //     'last_name' => 'required|string|max:255',
        //    // 'gender' => 'required|in:male,female,other',
        //     'address' => 'required|string|max:255',
        //     'zipcode' => 'required|string|max:10',
        //     'id_type' => 'required|string|max:255',
        //     'id_number' => 'required|string|max:255',
        //     //'id_verified' => 'required|boolean',
        // ]);

        // if ($validator->fails()) {
        //     if ($request->expectsJson()) {
        //         return response()->json(['res' => false, 'msg' => $validator->errors()->first(), 'data' => ''], 422);
        //     } else {
        //         return redirect()->back()->withErrors($validator)->withInput();
        //     }
        // }
        $user = User::findOrFail($id);
        
        // $user->name = $request->name;
        $user->email = $request->email;
        $user->mobile = $request->mobile;
        $user->verified = $request->verified;
        //  $user->status = $request->status;
       

        // Save the user
        $user->save();
        
            // Check if customerDetail exists, if not, create a new one
        if (!$user->customerDetail) {
            $customerDetail = new CustomerDetail();
            $user->customerDetail()->save($customerDetail);
        } else {
            $customerDetail = $user->customerDetail;
        }

        // Update CustomerDetail data
        $customerDetail->first_name = $request->first_name;
        $customerDetail->last_name = $request->last_name;
        $customerDetail->gender = $request->gender;
        $customerDetail->address = $request->address;
        $customerDetail->zipcode = $request->zipcode;
        $customerDetail->id_type = $request->id_type;
        $customerDetail->id_number = $request->id_number;
        $customerDetail->id_verified = $request->id_verified;
        // $customerDetail->status = $request->status;
       
        $customerDetail->save();


        return redirect()->route('admin.customers')->with('success', 'User updated successfully');
    }


    //Vendor list
    public function vendors()
    {

        $users = User::where('user_type', 3)->with('vendorDetails')->get();

        return view('backend.vendors.index', compact('users'));
    }

    // Function to show the edit form
    public function vendorEdit($id)
    {
        $user = User::findOrFail($id);
        return view('backend.vendors.edit', compact('user'));
    }

    public function vendorUpdate(Request $request, $id)
    {

        $validator = Validator::make($request->all(), [
            'bank_person_name' => 'nullable|string',
            'bank_acc_no' => 'nullable|string',
            'ifsc_code' => 'nullable|string',
            'bank_name' => 'nullable|string',
            'branch_name' => 'nullable|string',
            'cancelled_cheque' => 'nullable|file|mimes:jpeg,png,jpg,pdf|max:2048',
            'authorization_letter' => 'nullable|file|mimes:jpeg,png,jpg,pdf|max:2048',
        ]);

        if ($validator->fails()) {
           return redirect()->back()->withErrors($validator)->withInput();
        }
     
        
        $user = User::findOrFail($id);
        $previousStatus = $user->verified;
        
        $user->email = $request->email;
        $user->mobile = $request->mobile;
        $user->verified = $request->verified;
        //  $user->status = $request->status;
       

        // Save the user
        $user->save();
        if ($request->verified == 1 && !$previousStatus) {
            NotificationHelper::sendNotification($user->id, "Your account has been verified");
        }

        
        if (!$user->vendorDetails) {
        $vendorDetails = new VendorDetails();
        $user->vendorDetails()->save($vendorDetails);
        } else {
        $vendorDetails = $user->vendorDetails;
        }
            $vendorDetails = $user->vendorDetails;
            $previousBankStatus = $vendorDetails->bank_verified;
            $vendorDetails->fullname = $request->fullname;
            $vendorDetails->address = $request->address;
            $vendorDetails->pincode = $request->pincode;
            $vendorDetails->bank_person_name = $request->bank_person_name;
            $vendorDetails->bank_acc_no = $request->bank_acc_no;
            $vendorDetails->ifsc_code = $request->ifsc_code;
            $vendorDetails->bank_name = $request->bank_name;
            $vendorDetails->branch_name = $request->branch_name;
            //  $vendorDetails->cancelled_cheque = $request->cancelled_cheque;
            //   $vendorDetails->authorization_letter = $request->authorization_letter;
            $vendorDetails->bank_verified = $request->bank_verified;


            // Handle the cancelled_cheque file upload
            if ($request->hasFile('cancelled_cheque')) {
                $cancelledChequeFile = $request->file('cancelled_cheque');


                if ($cancelledChequeFile->isValid()) {

                    $filename = uniqid() . '_' . time() . '_' . $vendorDetails->user_id . '_' . $cancelledChequeFile->getClientOriginalName();


                    $cancelledChequeFile->storeAs('public/vendor_files/banking_details', $filename);


                    $vendorDetails->cancelled_cheque = 'vendor_files/banking_details/' . $filename;
                } else {

                    return response()->json(['success' => false, 'msg' => 'Invalid cancelled_cheque image file'], 400);
                }
            }

            if ($request->hasFile('authorization_letter')) {
                $authorizationLetterFile = $request->file('authorization_letter');


                if ($authorizationLetterFile->isValid()) {
                    $filename = uniqid() . '_' . time() . '_' . $vendorDetails->user_id . '_' . $authorizationLetterFile->getClientOriginalName();
                    $authorizationLetterFile->storeAs('public/vendor_files/banking_details', $filename);
                    $vendorDetails->authorization_letter = 'vendor_files/banking_details/' . $filename;
                } else {
                    return response()->json(['success' => false, 'msg' => 'Invalid authorization_letter image file'], 400);
                }
            }
            $vendorDetails->save();
            if ($request->bank_verified == 1 && !$previousBankStatus) {
                NotificationHelper::sendNotification($user->id, "Your Bank account has been verified");
            }
        
        

        return redirect()->route('admin.vendors')->with('success', 'Vendor Details updated successfully');
    }


   
    //Package list
    public function packages()
    {
   
    $allpackages = Package::with([
    'religion',

    'transportation',
    'typeoftourpackages',
    'trip',
    'stayPlans'
    ])
    ->join('states', 'packages.destination_state_id', '=', 'states.id')
    ->leftJoin('cities', 'packages.destination_city_id', '=', 'cities.id')
    ->leftJoin('type_of_tour_packages', 'packages.type_of_tour_packages_id', '=', 'type_of_tour_packages.id')
    ->leftJoin('vendor_details', 'packages.user_id', '=', 'vendor_details.user_id')
    ->select(
    'packages.*',
    'states.name as state_name',
    'cities.city as cities_name',
    'type_of_tour_packages.name as type_name',
    'vendor_details.fullname as vendor_name',
    )
    ->where('packages.status', '!=', 3)
    ->orderBy('packages.updated_at', 'desc')
    ->get();

    
    foreach ($allpackages as $package) {
    // Determine status
    if ($package->status == 0) {
    $status = "Inactive";
    } elseif ($package->status == 1) {
    $status = "Active";
    } elseif ($package->status == 2) {
    $status = "Approval Pending";
    } elseif ($package->status == 3) {
    $status = "Archive";
    } else {
    $status = ""; 
    }

    
    $originCityName = City::where('id', $package->origin_city_id)->value('city');

    
    $package->status_text = $status;
    $package->origin_city_name = $originCityName;
    }

    return view('backend.packages.index', compact('allpackages'));
    }

    
    
    public function packagesView($id)
    {
       
        $package = $this->adminService->getPackageDetails($id);

        if (!$package) {
            abort(404, 'Package not found');
        }
      
        $themesIds = explode(',', $package->themes_id);
        $themes = DB::table('themes')
        ->whereIn('id', $themesIds)
        ->select(['name'])
        ->get();
       
        $totalDays = $package->total_days;
        $totalNights = $package->stay_plan->sum('total_nights');
    //   $totalNights = 0;
    //   if ($package->stay_plan) {
    //     // If stay plans exist, calculate the total nights
    //     $totalNights = $package->stay_plan->sum('total_nights');
    // }


        $totalDaysAndNights = "$totalDays days and $totalNights night" . ($totalNights > 1 ? 's' : '');

     
        $galleryImages = [];
        foreach ($package->gallery_images as $image) {
            $galleryImages[] = [
                'id' => $image['id'],
                'path' => $image['path'],
            ];
        }

        $inclusions = DB::table('package_inclusions')
            ->whereIn('id', explode(',', $package->inclusions_in_package))
            ->select(['name'])
            ->get();

        
        $itinerary = $this->transformItinerary($package->itinerary);
        $originCityName = City::where('id', $package->origin_city_id)->value('city');
        $mediaLinks = $package->mediaLinks ?? [];
        $addons = $package->addons ?? [];
        $seatAvailability = $package->seatAvailability ?? [];
       // $itinerary = $package->itinerary ?? [];
        $inclusionList = $package->inclusions ?? [];
        $exclusionList = $package->exclusions ?? [];
        $stayPlan = $package->stay_plan;
        $transformedPackage = [
            'package_id' => $package->id,
            'vendor_name' => $package->vendor_name,
            'package_name' => $package->name,
            'total_days' => $totalDaysAndNights,
            'total_days_count' => (int)$totalDays,
            'total_nights_count' => (int)$totalNights,
            'starting_price' => isset($package->starting_price) ? round($package->starting_price) : null,
            'origin' => $originCityName,
            'destination_state_id' => $package->destination_state_id,
            'state_name' => $package->state_name,
            'destination_city_id' => $package->destination_city_id,
            'cities_name' => $package->cities_name,
            'keywords' => $package->keywords,
            'transportation_name' => isset($package->transportation->name) ? $package->transportation->name : null,
            'hotel_star' => isset($package->hotel_star_id) ? $package->hotel_star_id : null,
            'religion' => isset($package->religion->name) ? $package->religion->name : null,
            'trip_id' => $package->trip_id,
            'trip' => $package->trip->name,
            'type_of_tour_packages_id' => $package->type_of_tour_packages_id,
            'type_of_tour_packages' => $package->type_name,
            'themes' => $themes,
            'featured_image_path' => $package->featured_image_path,
            'inclusions_in_package' => $inclusions,
            'gallery_images' => $galleryImages,
            'verified' =>  $package->verified,
            'itinerary' => $itinerary,

            'overview' => $package->overview,
            'inclusions_list' => $inclusionList,
            'exclusions_list' => $exclusionList,
            'terms_and_condition' => $package->terms_and_condition,
            'payment_policy' => $package->payment_policy,
            'cancellation_policy' => $package->cancellation_policy,
            'child_discount' => $package->child_discount,
            'single_occupancy_cost' => $package->single_occupancy_cost,
            'offseason_from_date' => $package->offseason_from_date,
            'offseason_to_date' => $package->offseason_to_date,
            'offseason_price' => $package->offseason_price,
            'onseason_from_date' => $package->onseason_from_date,
            'onseason_to_date' => $package->onseason_to_date,
            'onseason_price' => $package->onseason_price,
            'total_seat' => $package->total_seat,
            'bulk_no_of_pax' => $package->bulk_no_of_pax,
            'pax_discount_percent' => $package->pax_discount_percent,
            'created_at' => date($package->created_at),
             'stay_plan' => $stayPlan,
             'media_link' => $mediaLinks,
             'addons' => $addons,
             'seat_availability' => $seatAvailability,
             'tour_circuit' => $package->tour_circuit,
             'location' => $package->location,
             'status' => $package->status,
             'is_transport' => $package->is_transport,
             'is_flight' => $package->is_flight,
             'is_train' => $package->is_train,
             'is_hotel' => $package->is_hotel,
             'is_meal' => $package->is_meal,
             'is_sightseeing' => $package->is_sightseeing,
             'triple_sharing_discount' => $package->triple_sharing_discount,
           
        ];

        //return response()->json(['res' => true, 'data' => $transformedPackage], 200);
        return view('backend.packages.view', compact('transformedPackage'));
    }
    private function transformItinerary($itineraries)
{
    return $itineraries->map(function ($itinerary) {
        // Initialize transformed data arrays
        $transformedFlights = [];
        $transformedTrains = [];
        $transformedHotels = [];

        // Process hotels
        foreach ($itinerary->hotel ?? [] as $hotel) {
            // Get hotel gallery images for each hotel
            $hotelGalleryImages = PackageHotelGalleryImage::where('hotel_id', $hotel->id)
                ->select('id', 'path')
                ->pluck('path', 'id')
                ->toArray();

            $galleryImages = [];
            foreach ($hotelGalleryImages as $id => $path) {
                $galleryImages[] = [
                    'id' => $id,
                    'path' => $path,
                ];
            }

            $transformedHotels[] = [
                'hotel_id' => $hotel->id,
                'hotel_name' => $hotel->name,
                'star' => $hotel->rating,
                'hotel_gallery' => $galleryImages,
            ];
        }

        // Process flights
        foreach ($itinerary->flight ?? [] as $flight) {
            // Retrieve city names for depart and arrive destinations
            $departCity = City::find($flight['depart_destination']);
            $arriveCity = City::find($flight['arrive_destination']);

            $transformedFlights[] = [
                'id' => $flight['id'],
                'depart_destination' => [
                    'id' => $flight['depart_destination'],
                    'name' => $departCity ? $departCity->city : null,
                ],
                'arrive_destination' => [
                    'id' => $flight['arrive_destination'],
                    'name' => $arriveCity ? $arriveCity->city : null,
                ],
                'depart_datetime' => $flight['depart_datetime'] ?? null,
                'arrive_datetime' => $flight['arrive_datetime'] ?? null,
            ];
        }

        // Process trains
        foreach ($itinerary->train ?? [] as $train) {
            // Retrieve city names for depart and arrive destinations
            $departCity = City::find($train['from_station']);
            $arriveCity = City::find($train['to_station']);

            $transformedTrains[] = [
                'id' => $train['id'],
                'depart_destination' => [
                    'id' => $train['from_station'],
                    'name' => $departCity ? $departCity->city : null,
                ],
                'arrive_destination' => [
                    'id' => $train['to_station'],
                    'name' => $arriveCity ? $arriveCity->city : null,
                ],
                'train_name' => $train['train_name'] ?? null,
                'train_number' => $train['train_number'] ?? null,
                'class' => $train['class'] ?? null,
                'depart_datetime' => $train['depart_datetime'] ?? null,
                'arrive_datetime' => $train['arrive_datetime'] ?? null,
            ];
        }

        // Retrieve city name for the place_name
        $placeNameCity = City::find($itinerary->place_name);
        $placeName = $placeNameCity ? $placeNameCity->city : null;

        // Return transformed itinerary data
        return [
            'itinerary_id' => $itinerary->id,
            'day' => $itinerary->day,
            'place_name' => $placeName,
            'itinerary_title' => $itinerary->itinerary_title,
            'itinerary_description' => $itinerary->itinerary_description,
            'meal' => $itinerary->meal,
            'flights' => $transformedFlights,
            'trains' => $transformedTrains,
            'local_transport' => $itinerary->local_transport ?? [],
            'sightseeing' => $itinerary->sightseeing ?? [],
            'hotels' => $transformedHotels,
        ];
    });
}


public function packagesUpdate(Request $request, $id)
{
    try {
        
        $package = Package::findOrFail($id);
        $package->verified = $request->verified;
        $package->save();
        return redirect()->route('admin.packages')->with('success', 'Package updated successfully');
    } catch (\Exception $e) {
        return redirect()->back()->with('error', 'Failed to update package: ' . $e->getMessage());
    }
}

public function renderHeader()
{
    
    $userId = auth()->id();

    $messages = NotificationHelper::getMessagesByUserId($userId);

    return view('header', ['messages' => $messages]);
}

// public function notificationList()
// {
//     $userId = auth()->id();
//     $notifications = NotificationHelper::getMessagesByUserId($userId);
//     return view('backend.notifications', compact('notifications'));
//   //  return view('backend.packages.view', compact('transformedPackage'));
// }

public function notificationList()
{
    $userId = auth()->id();
    $notifications = NotificationHelper::getMessagesByUserId($userId);
    Notification::markAllAsRead($userId);
    return view('backend.notification.index', compact('notifications'));
}
public function deleteNotification($id)
{
    $notification = Notification::findOrFail($id);
    $notification->delete();
    
    return redirect()->back()->with('success', 'Notification deleted successfully');
   
}
public function bulkDeleteNotifications(Request $request)
{
    $notificationIds = $request->input('ids');

    try {
        Notification::whereIn('id', $notificationIds)->delete();
        return response()->json(['success' => true]);
    } catch (\Exception $e) {
        return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
    }
}
public function markAllNotificationsAsRead()
    {
        try {
            $userId = auth()->id();
            // Mark all notifications as read for the logged-in user
            Notification::markAllAsRead($userId);
            return response()->json(['success' => true]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }

    public function clearAllNotifications()
{
    try {
        $userId = auth()->id();
        // Mark all notifications as read for the logged-in user
        Notification::where('receiver_id', $userId)->update(['read' => true]);
        return response()->json(['success' => true]);
    } catch (\Exception $e) {
        return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
    }
}

     public function removeAllNotifications()
       {
        try {
        $userId = auth()->id();
        // Delete all notifications for the logged-in user
        Notification::where('receiver_id', $userId)->delete();
        return response()->json(['success' => true]);
         } catch (\Exception $e) {
        return response()->json(['success' => false, 'error' => $e->getMessage()], 500);
         }
        }
        //Booking list
        public function booking()
        {
            $upcomingBookings = $this->adminService->getBookings();

            $resultBookings = $upcomingBookings->map(function ($booking) {
                $package = Package::find($booking->package_id);

                if ($package) {
                    $totalDays = $package->total_days;
                    $totalNights = $package->fetchStayPlans()->sum('total_nights');
                    $totalDaysAndNights = "$totalDays days and $totalNights night" . ($totalNights > 1 ? 's' : '');
                    $booking->total_days = $totalDaysAndNights;
                } else {
                    $booking->total_days = "Package not found";
                }

                return $booking;
            });

           // dd($resultBookings);
            return view('backend.booking.index', compact('resultBookings'));
        }

        public function bookingView($id)
     {
       
        $bookingdetails = $this->adminService->getBookingDetails($id);

        if (!$bookingdetails) {
            abort(404, 'Booking not found');
        }

        $booking_passengers = BookingPassenger::where('booking_id', $id)->get();

        //dd($booking_passengers);
        return view('backend.booking.view', compact('bookingdetails','booking_passengers'));
     }

}