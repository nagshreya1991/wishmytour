<?php

namespace Modules\Admin\App\Http\Services;

use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\DB;
use Modules\User\app\Models\User;
use Illuminate\Support\Facades\Validator;
use Modules\User\app\Models\CustomerDetail;
use Modules\User\app\Models\VendorDetails;
use Modules\User\app\Models\VendorPartners;
use Modules\User\app\Models\VendorDirectors;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use Modules\User\app\Models\VendorBroadLocation;
use Carbon\Carbon;
use App\Helpers\NotificationHelper;
use Modules\Package\app\Models\Package;
use Illuminate\Support\Facades\Log;
use Modules\Booking\app\Models\Booking;
use Modules\Booking\app\Models\BookingCustomerDetails;
use Modules\Booking\app\Models\BookingRoom;
use Modules\Booking\app\Models\BookingDate;
use Modules\Booking\app\Models\BookingPassenger;

class AdminService
{
    public function getPackageDetails($id)
    {
        try {
            $package = Package::with(['religion',  'transportation', 'typeoftourpackages', 'trip', 'cityStayPlans', 'inclusions', 'exclusions'])
                ->join('states', 'packages.destination_state_id', '=', 'states.id')
                ->join('cities', 'packages.destination_city_id', '=', 'cities.id')
                ->leftJoin('type_of_tour_packages', 'packages.type_of_tour_packages_id', '=', 'type_of_tour_packages.id')
                ->leftJoin('users', 'packages.user_id', '=', 'users.id')
                ->leftJoin('stay_plan', 'packages.id', '=', 'stay_plan.package_id')
                ->leftJoin('vendor_details', 'packages.user_id', '=', 'vendor_details.user_id')
                ->where('packages.id', $id)
                ->select(
                    'packages.*',
                    'states.name as state_name',
                    'cities.city as cities_name',
                    'type_of_tour_packages.name as type_name',
                    'vendor_details.fullname as vendor_name'
                )
                ->groupBy('packages.id', 'vendor_details.fullname')
                ->first();
                
            if (!$package) {
                return response()->json(['res' => false, 'msg' => 'Package not found'], 404);
            }

            $package->cancellation_policy = explode(',', $package->cancellation_policy);
            $package->stay_plan = $package->getItineraries($id);
            // fetch stay plan data according itineraries
           // $package->stay_plan = $this->transformItinerary($id);

           return $package;
        } catch (\Exception $e) {
            Log::error('Error occurred while fetching package details: ' . $e->getMessage());
            return ['res' => false, 'msg' => $e->getMessage()];
        }
    }

    public function getBookings()
    {
        return Booking::leftJoin('packages', 'bookings.package_id', '=', 'packages.id')
            ->leftJoin('booking_dates', 'booking_dates.booking_id', '=', 'bookings.id')
            ->leftJoin('vendor_details', 'packages.user_id', '=', 'vendor_details.user_id')
            ->leftJoin('customer_details', 'bookings.customer_id', '=', 'customer_details.user_id')
            ->select(
                'bookings.id as bookings_id',
                'bookings.*',
                'packages.id as package_id',
                'packages.*',
                'vendor_details.fullname as vendor_fullname',
                DB::raw('MAX(customer_details.first_name) as customer_first_name'),
                DB::raw('MAX(customer_details.last_name) as customer_last_name'),
                DB::raw('(SELECT MIN(booking_date) FROM booking_dates WHERE booking_id = bookings.id) as first_booking_date'),
                DB::raw('(SELECT MAX(booking_date) FROM booking_dates WHERE booking_id = bookings.id) as last_booking_date'),
                DB::raw('(SELECT path FROM package_gallery_images WHERE package_id = packages.id ORDER BY id ASC LIMIT 1) as first_gallery_image'),
                DB::raw('(SELECT SUM(adults + children) FROM booking_rooms WHERE booking_id = bookings.id) as total_pax')
            )
            ->groupBy('bookings.id', 'vendor_details.fullname')
            ->orderBy('first_booking_date', 'asc')
            ->get();
    }
    
    public function getBookingDetails($id)
    {
        try {
            $booking = Booking::leftJoin('packages', 'bookings.package_id', '=', 'packages.id')
            ->leftJoin('vendor_details', 'packages.user_id', '=', 'vendor_details.user_id')
            ->leftJoin('customer_details', 'bookings.customer_id', '=', 'customer_details.user_id')
            ->leftJoin('booking_customer_details', 'bookings.id', '=', 'booking_customer_details.booking_id')
            ->leftJoin('cities', 'customer_details.city', '=', 'cities.id')
            ->leftJoin('states', 'customer_details.state', '=', 'states.id')
            ->leftJoin('users', 'bookings.customer_id', '=', 'users.id')
            ->leftJoin('booking_dates', 'booking_dates.booking_id', '=', 'bookings.id')
            
            ->select(

            'bookings.*',
            'bookings.id as bookings_id',
            'booking_customer_details.*',
            'vendor_details.*',
            'customer_details.*',
            'users.id as user_id',
            'packages.*',
            'vendor_details.fullname as vendor_fullname',
            'customer_details.id as customer_id',
            'customer_details.first_name as customer_first_name',
            'customer_details.last_name as customer_last_name',
            'booking_customer_details.name as booking_customer_name',

            'booking_customer_details.address as booking_customer_address',
            'booking_customer_details.email as booking_customer_email',
            'booking_customer_details.phone_number as booking_customer_phone_number',
            'booking_customer_details.pan_number as booking_customer_pan_number',
            'cities.city as customer_city',
            'states.name as customer_state',
            DB::raw('(SELECT MIN(booking_date) FROM booking_dates WHERE booking_id = bookings.id) as first_booking_date'),
            DB::raw('(SELECT MAX(booking_date) FROM booking_dates WHERE booking_id = bookings.id) as last_booking_date'),
            
            )
            ->where('bookings.id', $id)

            ->first();
            
    
            if (!$booking) {
                return response()->json(['res' => false, 'msg' => 'Booking not found'], 404);
            }
 
            return $booking;
        } catch (\Exception $e) {
            Log::error('Error occurred while fetching package details: ' . $e->getMessage());
            return ['res' => false, 'msg' => $e->getMessage()];
        }
    }

    

}
