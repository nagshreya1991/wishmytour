<?php
declare(strict_types=1);

namespace Lcobucci\JWT\Validation;

interface ValidAt extends Constraint
{
}
